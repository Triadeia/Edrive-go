"use client";

import { useCalculator } from "./CalculatorContext";

/** Banner de alertas de validação (avisos e perigos). */
export default function AlertBanner() {
  const { alerts } = useCalculator();

  if (alerts.length === 0) {
    return (
      <div className="rounded-xl border border-brand-700/50 bg-brand-900/30 px-4 py-3 text-sm text-brand-300">
        ✓ Nenhum alerta — as premissas estão dentro das faixas saudáveis.
      </div>
    );
  }

  return (
    <div className="space-y-2">
      {alerts.map((a, i) => {
        const perigo = a.severidade === "perigo";
        return (
          <div
            key={`${a.campo}-${i}`}
            className={`flex items-start gap-2 rounded-xl border px-4 py-3 text-sm ${
              perigo
                ? "border-red-800/60 bg-red-950/40 text-red-200"
                : "border-amber-800/60 bg-amber-950/30 text-amber-200"
            }`}
          >
            <span>{perigo ? "⛔" : "⚠️"}</span>
            <div>
              <span className="font-semibold">
                {perigo ? "Perigo" : "Aviso"} ({a.campo}):{" "}
              </span>
              {a.mensagem}
            </div>
          </div>
        );
      })}
    </div>
  );
}
