"use client";

/**
 * CalculatorContext — estado central da aplicação via useReducer + Context.
 * Sincroniza com a URL (querystring) e o localStorage a cada mudança.
 * O cálculo em si continua na engine pura; aqui só orquestramos estado + memo.
 */

import {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useReducer,
  useRef,
} from "react";
import type { Assumptions, AssumptionKey } from "@/types/business";
import type {
  CalculationResult,
  ScenarioId,
  ScenarioResult,
  ValidationAlert,
} from "@/types/calculator";
import { calculate, calculateScenarios } from "@/lib/calculationEngine";
import { validateAssumptions } from "@/lib/validations";
import { defaultAssumptions } from "@/data/defaultAssumptions";
import { scenarios } from "@/lib/scenarios";
import {
  loadInitialState,
  pushStateToUrl,
  saveToLocalStorage,
} from "@/lib/urlState";

interface State {
  assumptions: Assumptions;
  scenarioId: ScenarioId;
}

type Action =
  | { type: "SET_FIELD"; campo: AssumptionKey; valor: number }
  | { type: "SET_SCENARIO"; scenarioId: ScenarioId }
  | { type: "RESET" }
  | { type: "HYDRATE"; state: State };

function reducer(state: State, action: Action): State {
  switch (action.type) {
    case "SET_FIELD":
      return {
        ...state,
        assumptions: { ...state.assumptions, [action.campo]: action.valor },
      };
    case "SET_SCENARIO": {
      // Ao trocar de cenário, aplica os overrides sobre a base padrão.
      const overrides = scenarios[action.scenarioId].overrides;
      return {
        scenarioId: action.scenarioId,
        assumptions: { ...defaultAssumptions, ...overrides },
      };
    }
    case "RESET":
      return { assumptions: { ...defaultAssumptions }, scenarioId: "base" };
    case "HYDRATE":
      return action.state;
    default:
      return state;
  }
}

interface CalculatorContextValue {
  assumptions: Assumptions;
  scenarioId: ScenarioId;
  result: CalculationResult;
  alerts: ValidationAlert[];
  scenarioResults: ScenarioResult[];
  setField: (campo: AssumptionKey, valor: number) => void;
  setScenario: (id: ScenarioId) => void;
  reset: () => void;
}

const Ctx = createContext<CalculatorContextValue | null>(null);

export function CalculatorProvider({ children }: { children: React.ReactNode }) {
  // Estado inicial determinístico (padrão base) para casar SSR/CSR.
  const [state, dispatch] = useReducer(reducer, {
    assumptions: { ...defaultAssumptions },
    scenarioId: "base" as ScenarioId,
  });

  const hydrated = useRef(false);

  // Hidrata do URL/localStorage apenas no cliente, após o mount.
  useEffect(() => {
    const initial = loadInitialState();
    dispatch({ type: "HYDRATE", state: initial });
    hydrated.current = true;
  }, []);

  // Persiste no URL + localStorage a cada mudança (depois de hidratar).
  useEffect(() => {
    if (!hydrated.current) return;
    const persisted = {
      assumptions: state.assumptions,
      scenarioId: state.scenarioId,
    };
    pushStateToUrl(persisted);
    saveToLocalStorage(persisted);
  }, [state]);

  // Cálculo memoizado — só recalcula quando as premissas mudam.
  const result = useMemo(() => calculate(state.assumptions), [state.assumptions]);
  const alerts = useMemo(
    () => validateAssumptions(state.assumptions, result),
    [state.assumptions, result]
  );
  const scenarioResults = useMemo(
    () => calculateScenarios(defaultAssumptions),
    []
  );

  const value: CalculatorContextValue = {
    assumptions: state.assumptions,
    scenarioId: state.scenarioId,
    result,
    alerts,
    scenarioResults,
    setField: (campo, valor) => dispatch({ type: "SET_FIELD", campo, valor }),
    setScenario: (id) => dispatch({ type: "SET_SCENARIO", scenarioId: id }),
    reset: () => dispatch({ type: "RESET" }),
  };

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useCalculator(): CalculatorContextValue {
  const ctx = useContext(Ctx);
  if (!ctx) {
    throw new Error("useCalculator deve ser usado dentro de <CalculatorProvider>.");
  }
  return ctx;
}
