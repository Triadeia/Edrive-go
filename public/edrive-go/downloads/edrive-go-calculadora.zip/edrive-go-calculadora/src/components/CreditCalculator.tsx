"use client";

import { useCalculator } from "./CalculatorContext";
import InputCard from "./InputCard";
import SliderInput from "./SliderInput";
import { formatInt, formatBRL } from "@/lib/formatters";

/** Bloco CRÉDITO / CONSÓRCIO: receita complementar. */
export default function CreditCalculator() {
  const { assumptions: a, setField, result } = useCalculator();
  const c = result.credit;

  return (
    <InputCard titulo="Crédito / Consórcio" descricao="Receita complementar via consórcio" icone="🏦">
      <SliderInput label="Interessados em consórcio" valor={a.pctInteressadosConsorcio} onChange={(v) => setField("pctInteressadosConsorcio", v)} min={0} max={1} step={0.05} modoPercentual />
      <SliderInput label="Conversão em consórcio" valor={a.taxaConversaoConsorcio} onChange={(v) => setField("taxaConversaoConsorcio", v)} min={0} max={1} step={0.01} modoPercentual />
      <SliderInput label="Comissão média por carta" valor={a.comissaoMediaConsorcio} onChange={(v) => setField("comissaoMediaConsorcio", v)} min={0} max={10000} step={100} prefixo="R$" />
      <SliderInput label="Ticket médio da carta" valor={a.ticketMedioCarta} onChange={(v) => setField("ticketMedioCarta", v)} min={0} max={300000} step={5000} prefixo="R$" />
      <SliderInput label="Cancelamento de consórcio" valor={a.pctCancelamentoConsorcio} onChange={(v) => setField("pctCancelamentoConsorcio", v)} min={0} max={0.6} step={0.01} modoPercentual />
      <SliderInput label="Custo de compliance por operação" valor={a.custoCompliancePorOp} onChange={(v) => setField("custoCompliancePorOp", v)} min={0} max={1000} step={10} prefixo="R$" />

      <div className="mt-2 grid grid-cols-2 gap-2 rounded-lg bg-surface-soft p-3 text-xs">
        <div>
          <span className="text-slate-400">Cartas vendidas: </span>
          <span className="font-semibold text-slate-100">{formatInt(c.cartasVendidas)}</span>
        </div>
        <div>
          <span className="text-slate-400">Receita líq. consórcio: </span>
          <span className="font-semibold text-slate-100">{formatBRL(c.receitaLiquidaConsorcio)}</span>
        </div>
      </div>
    </InputCard>
  );
}
