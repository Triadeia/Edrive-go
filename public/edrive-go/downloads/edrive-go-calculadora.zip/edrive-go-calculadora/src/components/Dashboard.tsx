"use client";

import { useCalculator } from "./CalculatorContext";
import ResultCard from "./ResultCard";
import {
  formatBRL,
  formatInt,
  formatPct,
  formatRatio,
  formatNum,
} from "@/lib/formatters";

/** Painel de KPIs principais da operação. */
export default function Dashboard() {
  const { result } = useCalculator();
  const { dre, funnel, fleet, unitEconomics, breakEven, cashFlow, offer } =
    result;

  return (
    <section className="rounded-2xl border border-surface-border bg-surface-card/60 p-5">
      <h2 className="mb-4 text-sm font-semibold uppercase tracking-wide text-brand-400">
        Dashboard — Resultados do mês
      </h2>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
        <ResultCard
          titulo="Receita bruta"
          valor={formatBRL(offer.receitaBruta)}
          tom="destaque"
        />
        <ResultCard
          titulo="Receita líquida"
          valor={formatBRL(offer.receitaLiquida)}
        />
        <ResultCard
          titulo="Custo frota"
          valor={formatBRL(fleet.custoFrota)}
          tom="negativo"
        />
        <ResultCard
          titulo="EBITDA"
          valor={formatBRL(dre.ebitda)}
          tom={dre.ebitda >= 0 ? "positivo" : "negativo"}
        />
        <ResultCard
          titulo="Lucro líquido"
          valor={formatBRL(dre.lucroLiquido)}
          tom={dre.lucroLiquido >= 0 ? "positivo" : "negativo"}
        />
        <ResultCard
          titulo="Margem líquida"
          valor={formatPct(dre.margemLiquidaPct)}
          tom={dre.margemLiquidaPct >= 0 ? "positivo" : "negativo"}
        />
        <ResultCard titulo="CAC total" valor={formatBRL(funnel.cacTotal)} />
        <ResultCard titulo="LTV" valor={formatBRL(unitEconomics.ltv)} />
        <ResultCard
          titulo="LTV / CAC"
          valor={formatRatio(unitEconomics.ltvCac)}
          tom={unitEconomics.ltvCac >= 3 ? "positivo" : "negativo"}
          detalhe="ideal ≥ 3x"
        />
        <ResultCard
          titulo="Payback CAC"
          valor={`${formatNum(unitEconomics.paybackCacMeses, 1)} meses`}
        />
        <ResultCard
          titulo="Break-even carros"
          valor={formatInt(breakEven.breakEvenCarros)}
          tom={breakEven.breakEvenCarros <= fleet.carrosAtivos ? "positivo" : "negativo"}
          detalhe={`ativos: ${formatInt(fleet.carrosAtivos)}`}
        />
        <ResultCard
          titulo="Carros ativos"
          valor={formatInt(fleet.carrosAtivos)}
        />
        <ResultCard
          titulo="Caixa mensal"
          valor={formatBRL(cashFlow.caixaMensal)}
          tom={cashFlow.caixaMensal >= 0 ? "positivo" : "negativo"}
          detalhe={`caixa final: ${formatBRL(cashFlow.caixaFinal)}`}
        />
      </div>
    </section>
  );
}
