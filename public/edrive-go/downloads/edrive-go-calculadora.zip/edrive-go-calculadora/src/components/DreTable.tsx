"use client";

import { useCalculator } from "./CalculatorContext";
import { formatBRL, formatPct } from "@/lib/formatters";

/** Linha da DRE. */
function Linha({
  rotulo,
  valor,
  negativo = false,
  destaque = false,
  indent = false,
}: {
  rotulo: string;
  valor: string;
  negativo?: boolean;
  destaque?: boolean;
  indent?: boolean;
}) {
  return (
    <div
      className={`flex items-center justify-between py-1.5 ${
        destaque
          ? "border-t border-surface-border font-semibold text-slate-100"
          : "text-slate-300"
      }`}
    >
      <span className={indent ? "pl-4 text-sm text-slate-400" : "text-sm"}>
        {rotulo}
      </span>
      <span
        className={`tabular-nums ${negativo ? "text-red-400" : ""} ${
          destaque ? "text-base" : "text-sm"
        }`}
      >
        {valor}
      </span>
    </div>
  );
}

/** Tabela da Demonstração de Resultado (DRE) do mês. */
export default function DreTable() {
  const { result } = useCalculator();
  const d = result.dre;

  return (
    <section className="rounded-2xl border border-surface-border bg-surface-card p-5">
      <h2 className="mb-3 text-sm font-semibold uppercase tracking-wide text-brand-400">
        DRE — Demonstração de Resultado (mensal)
      </h2>
      <div className="divide-y divide-surface-border/40">
        <Linha rotulo="(+) Receita bruta" valor={formatBRL(d.receitaBruta)} />
        <Linha rotulo="(−) Deduções / impostos" valor={`-${formatBRL(d.deducoes)}`} negativo indent />
        <Linha rotulo="(=) Receita líquida" valor={formatBRL(d.receitaLiquida)} destaque />
        <Linha rotulo="(−) Custo da frota" valor={`-${formatBRL(d.custoFrota)}`} negativo indent />
        <Linha rotulo="(−) Perda por inadimplência" valor={`-${formatBRL(d.perdaInadimplencia)}`} negativo indent />
        <Linha rotulo="(=) Margem bruta" valor={formatBRL(d.margemBruta)} destaque />
        <Linha rotulo="(−) Despesas de marketing" valor={`-${formatBRL(d.despesasMarketing)}`} negativo indent />
        <Linha rotulo="(−) Despesas comerciais" valor={`-${formatBRL(d.despesasComerciais)}`} negativo indent />
        <Linha rotulo="(−) Despesas operacionais" valor={`-${formatBRL(d.despesasOperacionais)}`} negativo indent />
        <Linha rotulo="(−) Despesas administrativas" valor={`-${formatBRL(d.despesasAdministrativas)}`} negativo indent />
        <Linha rotulo="(=) EBITDA" valor={formatBRL(d.ebitda)} destaque />
        <Linha rotulo="(−) Depreciação" valor={`-${formatBRL(d.depreciacao)}`} negativo indent />
        <Linha rotulo="(−) Resultado financeiro" valor={`-${formatBRL(d.resultadoFinanceiro)}`} negativo indent />
        <Linha rotulo="(−) Impostos sobre lucro" valor={`-${formatBRL(d.impostosSobreLucro)}`} negativo indent />
        <Linha rotulo="(=) Lucro líquido" valor={formatBRL(d.lucroLiquido)} destaque />
        <Linha rotulo="Margem líquida" valor={formatPct(d.margemLiquidaPct)} />
      </div>
    </section>
  );
}
