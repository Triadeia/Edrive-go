"use client";

import { useCalculator } from "./CalculatorContext";
import InputCard from "./InputCard";
import SliderInput from "./SliderInput";
import { formatBRL, formatInt } from "@/lib/formatters";

/** Bloco FROTA: custos por carro, ocupação e sinistros. */
export default function FleetCalculator() {
  const { assumptions: a, setField, result } = useCalculator();

  return (
    <InputCard titulo="Frota" descricao="Custos e disponibilidade dos 100 BYD Dolphin Mini" icone="🚗">
      <SliderInput label="Total de carros" valor={a.totalCarros} onChange={(v) => setField("totalCarros", v)} min={1} max={500} step={1} sufixo="un" />
      <SliderInput label="Aluguel do veículo (locadora)" valor={a.custoAluguelVeiculoMes} onChange={(v) => setField("custoAluguelVeiculoMes", v)} min={0} max={6000} step={50} prefixo="R$" />
      <SliderInput label="Seguro" valor={a.seguroMes} onChange={(v) => setField("seguroMes", v)} min={0} max={1000} step={10} prefixo="R$" />
      <SliderInput label="Telemetria" valor={a.telemetriaMes} onChange={(v) => setField("telemetriaMes", v)} min={0} max={300} step={5} prefixo="R$" />
      <SliderInput label="Manutenção" valor={a.manutencaoMes} onChange={(v) => setField("manutencaoMes", v)} min={0} max={800} step={10} prefixo="R$" />
      <SliderInput label="Pneus" valor={a.pneusMes} onChange={(v) => setField("pneusMes", v)} min={0} max={400} step={5} prefixo="R$" />
      <SliderInput label="Lavagem" valor={a.lavagemMes} onChange={(v) => setField("lavagemMes", v)} min={0} max={400} step={5} prefixo="R$" />
      <SliderInput label="Pátio + administração" valor={a.patioAdminMes} onChange={(v) => setField("patioAdminMes", v)} min={0} max={600} step={10} prefixo="R$" />
      <SliderInput label="Taxa de ocupação" valor={a.taxaOcupacao} onChange={(v) => setField("taxaOcupacao", v)} min={0} max={1} step={0.01} modoPercentual />
      <SliderInput label="Carros parados" valor={a.pctCarrosParados} onChange={(v) => setField("pctCarrosParados", v)} min={0} max={0.5} step={0.01} modoPercentual />
      <SliderInput label="Sinistros por mês" valor={a.pctSinistroMes} onChange={(v) => setField("pctSinistroMes", v)} min={0} max={0.1} step={0.005} modoPercentual />
      <SliderInput label="Custo médio por sinistro" valor={a.custoSinistroMedio} onChange={(v) => setField("custoSinistroMedio", v)} min={0} max={10000} step={100} prefixo="R$" />

      <div className="mt-2 grid grid-cols-2 gap-2 rounded-lg bg-surface-soft p-3 text-xs">
        <div>
          <span className="text-slate-400">Carros ativos: </span>
          <span className="font-semibold text-slate-100">{formatInt(result.fleet.carrosAtivos)}</span>
        </div>
        <div>
          <span className="text-slate-400">Custo frota/mês: </span>
          <span className="font-semibold text-slate-100">{formatBRL(result.fleet.custoFrota)}</span>
        </div>
        <div className="col-span-2">
          <span className="text-slate-400">Custo por carro: </span>
          <span className="font-semibold text-slate-100">{formatBRL(result.fleet.custoFrotaPorCarro)}</span>
        </div>
      </div>
    </InputCard>
  );
}
