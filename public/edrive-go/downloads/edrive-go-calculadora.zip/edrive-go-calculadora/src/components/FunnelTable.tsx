"use client";

import { useCalculator } from "./CalculatorContext";
import { formatInt, formatBRL } from "@/lib/formatters";

/** Tabela do funil de marketing: de leads a contratos. */
export default function FunnelTable() {
  const { result, assumptions } = useCalculator();
  const f = result.funnel;

  const etapas: { rotulo: string; valor: number }[] = [
    { rotulo: "Leads gerados", valor: f.leadsGerados },
    { rotulo: "Participantes do webinar", valor: f.participantesWebinar },
    { rotulo: "Aplicações", valor: f.aplicacoes },
    { rotulo: "Aprovados em crédito", valor: f.aprovados },
    { rotulo: "Contratos fechados", valor: f.contratos },
  ];

  const topo = etapas[0].valor || 1;

  return (
    <section className="rounded-2xl border border-surface-border bg-surface-card p-5">
      <h2 className="mb-3 text-sm font-semibold uppercase tracking-wide text-brand-400">
        Funil de marketing
      </h2>
      <div className="space-y-2">
        {etapas.map((e) => {
          const pct = Math.max(2, (e.valor / topo) * 100);
          return (
            <div key={e.rotulo}>
              <div className="mb-1 flex items-center justify-between text-sm">
                <span className="text-slate-300">{e.rotulo}</span>
                <span className="tabular-nums font-medium text-slate-100">
                  {formatInt(e.valor)}
                </span>
              </div>
              <div className="h-2 w-full overflow-hidden rounded-full bg-surface-soft">
                <div
                  className="h-full rounded-full bg-brand-500"
                  style={{ width: `${pct}%` }}
                />
              </div>
            </div>
          );
        })}
      </div>
      <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
        <div className="rounded-lg bg-surface-soft p-3">
          <div className="text-[11px] uppercase text-slate-400">CAC marketing</div>
          <div className="font-semibold text-slate-100">
            {formatBRL(f.cacMarketing)}
          </div>
        </div>
        <div className="rounded-lg bg-surface-soft p-3">
          <div className="text-[11px] uppercase text-slate-400">CAC total</div>
          <div className="font-semibold text-slate-100">
            {formatBRL(f.cacTotal)}
          </div>
        </div>
      </div>
      <p className="mt-3 text-[11px] text-slate-500">
        Investimento de mídia: {formatBRL(assumptions.investimentoMarketingMes)} · CPL:{" "}
        {formatBRL(assumptions.cpl)}
      </p>
    </section>
  );
}
