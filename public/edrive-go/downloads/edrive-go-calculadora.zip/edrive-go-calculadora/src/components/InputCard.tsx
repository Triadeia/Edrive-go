"use client";

/** Card contêiner de um bloco de inputs (ex.: FROTA, MARKETING). */
export default function InputCard({
  titulo,
  descricao,
  icone,
  children,
}: {
  titulo: string;
  descricao?: string;
  icone?: string;
  children: React.ReactNode;
}) {
  return (
    <section className="rounded-2xl border border-surface-border bg-surface-card p-5 shadow-lg">
      <header className="mb-4 flex items-start gap-3">
        {icone && <span className="text-2xl leading-none">{icone}</span>}
        <div>
          <h2 className="text-sm font-semibold uppercase tracking-wide text-brand-400">
            {titulo}
          </h2>
          {descricao && (
            <p className="mt-0.5 text-xs text-slate-400">{descricao}</p>
          )}
        </div>
      </header>
      <div className="space-y-4">{children}</div>
    </section>
  );
}
