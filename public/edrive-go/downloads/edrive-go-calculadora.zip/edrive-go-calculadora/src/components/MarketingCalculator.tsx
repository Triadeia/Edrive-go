"use client";

import { useCalculator } from "./CalculatorContext";
import InputCard from "./InputCard";
import SliderInput from "./SliderInput";
import { formatInt, formatBRL } from "@/lib/formatters";

/** Bloco MARKETING: investimento, CPL e taxas do funil. */
export default function MarketingCalculator() {
  const { assumptions: a, setField, result } = useCalculator();

  return (
    <InputCard titulo="Marketing" descricao="Investimento de mídia e taxas do funil" icone="📣">
      <SliderInput label="Investimento em mídia/mês" valor={a.investimentoMarketingMes} onChange={(v) => setField("investimentoMarketingMes", v)} min={0} max={200000} step={1000} prefixo="R$" />
      <SliderInput label="CPL (custo por lead)" valor={a.cpl} onChange={(v) => setField("cpl", v)} min={1} max={150} step={1} prefixo="R$" />
      <SliderInput label="Lead → grupo" valor={a.taxaLeadParaGrupo} onChange={(v) => setField("taxaLeadParaGrupo", v)} min={0} max={1} step={0.05} modoPercentual />
      <SliderInput label="Grupo → webinar" valor={a.taxaGrupoParaWebinar} onChange={(v) => setField("taxaGrupoParaWebinar", v)} min={0} max={1} step={0.05} modoPercentual />
      <SliderInput label="Comparecimento ao webinar" valor={a.taxaComparecimento} onChange={(v) => setField("taxaComparecimento", v)} min={0} max={1} step={0.05} modoPercentual />
      <SliderInput label="Taxa de aplicação" valor={a.taxaAplicacao} onChange={(v) => setField("taxaAplicacao", v)} min={0} max={1} step={0.05} modoPercentual />
      <SliderInput label="Taxa de aprovação (crédito)" valor={a.taxaAprovacao} onChange={(v) => setField("taxaAprovacao", v)} min={0} max={1} step={0.05} modoPercentual />
      <SliderInput label="Taxa de fechamento" valor={a.taxaFechamento} onChange={(v) => setField("taxaFechamento", v)} min={0} max={1} step={0.05} modoPercentual />

      <div className="mt-2 grid grid-cols-2 gap-2 rounded-lg bg-surface-soft p-3 text-xs">
        <div>
          <span className="text-slate-400">Leads: </span>
          <span className="font-semibold text-slate-100">{formatInt(result.funnel.leadsGerados)}</span>
        </div>
        <div>
          <span className="text-slate-400">Contratos: </span>
          <span className="font-semibold text-slate-100">{formatInt(result.funnel.contratos)}</span>
        </div>
        <div className="col-span-2">
          <span className="text-slate-400">CAC total: </span>
          <span className="font-semibold text-slate-100">{formatBRL(result.funnel.cacTotal)}</span>
        </div>
      </div>
    </InputCard>
  );
}
