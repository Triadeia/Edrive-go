"use client";

/** Campo numérico controlado com sufixo/prefixo opcional. */
export default function NumberInput({
  valor,
  onChange,
  step = 1,
  min,
  max,
  prefixo,
  sufixo,
  ariaLabel,
}: {
  valor: number;
  onChange: (v: number) => void;
  step?: number;
  min?: number;
  max?: number;
  prefixo?: string;
  sufixo?: string;
  ariaLabel?: string;
}) {
  return (
    <div className="flex items-center rounded-lg border border-surface-border bg-surface-soft px-2 focus-within:border-brand-500">
      {prefixo && <span className="text-xs text-slate-400">{prefixo}</span>}
      <input
        type="number"
        aria-label={ariaLabel}
        className="w-full bg-transparent px-1 py-1.5 text-right text-sm font-medium text-slate-100 outline-none [appearance:textfield] [&::-webkit-inner-spin-button]:appearance-none"
        value={Number.isFinite(valor) ? valor : 0}
        step={step}
        min={min}
        max={max}
        onChange={(e) => {
          const n = Number(e.target.value);
          onChange(Number.isFinite(n) ? n : 0);
        }}
      />
      {sufixo && <span className="pl-1 text-xs text-slate-400">{sufixo}</span>}
    </div>
  );
}
