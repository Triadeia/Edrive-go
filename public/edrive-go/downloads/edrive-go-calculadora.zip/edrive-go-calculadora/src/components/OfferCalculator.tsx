"use client";

import { useCalculator } from "./CalculatorContext";
import InputCard from "./InputCard";
import SliderInput from "./SliderInput";
import { formatBRL } from "@/lib/formatters";

/** Bloco OFERTA AO MOTORISTA: preço, ativação, churn e inadimplência. */
export default function OfferCalculator() {
  const { assumptions: a, setField, result } = useCalculator();

  return (
    <InputCard titulo="Oferta ao motorista" descricao="Preço, ativação e riscos de crédito" icone="💳">
      <SliderInput label="Mensalidade do motorista" valor={a.valorMensalMotorista} onChange={(v) => setField("valorMensalMotorista", v)} min={1000} max={7000} step={50} prefixo="R$" />
      <SliderInput label="Valor semanal (referência)" valor={a.valorSemanalMotorista} onChange={(v) => setField("valorSemanalMotorista", v)} min={200} max={2000} step={10} prefixo="R$" />
      <SliderInput label="Valor por dia (referência)" valor={a.valorDiaMotorista} onChange={(v) => setField("valorDiaMotorista", v)} min={50} max={400} step={5} prefixo="R$" />
      <SliderInput label="Taxa de ativação" valor={a.taxaAtivacao} onChange={(v) => setField("taxaAtivacao", v)} min={0} max={2000} step={50} prefixo="R$" />
      <SliderInput label="Sinal / caução (referência)" valor={a.entradaSinalCaucao} onChange={(v) => setField("entradaSinalCaucao", v)} min={0} max={5000} step={50} prefixo="R$" />
      <SliderInput label="Churn mensal" valor={a.churnMensal} onChange={(v) => setField("churnMensal", v)} min={0.01} max={0.3} step={0.005} modoPercentual />
      <SliderInput label="Inadimplência mensal" valor={a.inadimplenciaMensal} onChange={(v) => setField("inadimplenciaMensal", v)} min={0} max={0.4} step={0.005} modoPercentual />
      <SliderInput label="Recuperação da inadimplência" valor={a.pctRecuperacaoInadimplencia} onChange={(v) => setField("pctRecuperacaoInadimplencia", v)} min={0} max={1} step={0.05} modoPercentual />
      <SliderInput label="Prazo médio do contrato" valor={a.prazoMedioContratoMeses} onChange={(v) => setField("prazoMedioContratoMeses", v)} min={1} max={48} step={1} sufixo="m" />

      <div className="mt-2 grid grid-cols-2 gap-2 rounded-lg bg-surface-soft p-3 text-xs">
        <div>
          <span className="text-slate-400">Receita mensal frota: </span>
          <span className="font-semibold text-slate-100">{formatBRL(result.offer.receitaMensalFrota)}</span>
        </div>
        <div>
          <span className="text-slate-400">Margem contrib./carro: </span>
          <span className={`font-semibold ${result.unitEconomics.margemContribuicaoPorCarro < 0 ? "text-red-400" : "text-brand-400"}`}>
            {formatBRL(result.unitEconomics.margemContribuicaoPorCarro)}
          </span>
        </div>
      </div>
    </InputCard>
  );
}
