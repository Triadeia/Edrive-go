"use client";

/**
 * ResultCard — KPI de resultado (rótulo, valor, e cor por tom).
 */
export default function ResultCard({
  titulo,
  valor,
  detalhe,
  tom = "neutro",
}: {
  titulo: string;
  valor: string;
  detalhe?: string;
  tom?: "neutro" | "positivo" | "negativo" | "destaque";
}) {
  const cor =
    tom === "positivo"
      ? "text-brand-400"
      : tom === "negativo"
      ? "text-red-400"
      : tom === "destaque"
      ? "text-sky-300"
      : "text-slate-100";

  const borda =
    tom === "positivo"
      ? "border-brand-700/50"
      : tom === "negativo"
      ? "border-red-800/50"
      : "border-surface-border";

  return (
    <div
      className={`rounded-xl border ${borda} bg-surface-card p-4 shadow-sm`}
    >
      <div className="text-[11px] font-medium uppercase tracking-wide text-slate-400">
        {titulo}
      </div>
      <div className={`mt-1 text-xl font-bold tabular-nums ${cor}`}>{valor}</div>
      {detalhe && <div className="mt-0.5 text-[11px] text-slate-500">{detalhe}</div>}
    </div>
  );
}
