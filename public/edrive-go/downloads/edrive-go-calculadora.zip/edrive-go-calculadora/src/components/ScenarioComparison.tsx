"use client";

import { useCalculator } from "./CalculatorContext";
import { formatBRL, formatInt, formatPct, formatRatio } from "@/lib/formatters";

/** Comparação lado a lado dos 4 cenários. */
export default function ScenarioComparison() {
  const { scenarioResults } = useCalculator();

  const linhas: {
    rotulo: string;
    fmt: (r: (typeof scenarioResults)[number]["result"]) => string;
    melhorMaior?: boolean;
  }[] = [
    { rotulo: "Receita bruta", fmt: (r) => formatBRL(r.offer.receitaBruta), melhorMaior: true },
    { rotulo: "Receita líquida", fmt: (r) => formatBRL(r.offer.receitaLiquida), melhorMaior: true },
    { rotulo: "Custo frota", fmt: (r) => formatBRL(r.fleet.custoFrota) },
    { rotulo: "Margem bruta", fmt: (r) => formatBRL(r.dre.margemBruta), melhorMaior: true },
    { rotulo: "EBITDA", fmt: (r) => formatBRL(r.dre.ebitda), melhorMaior: true },
    { rotulo: "Lucro líquido", fmt: (r) => formatBRL(r.dre.lucroLiquido), melhorMaior: true },
    { rotulo: "Margem líquida", fmt: (r) => formatPct(r.dre.margemLiquidaPct), melhorMaior: true },
    { rotulo: "Contratos/mês", fmt: (r) => formatInt(r.funnel.contratos), melhorMaior: true },
    { rotulo: "CAC total", fmt: (r) => formatBRL(r.funnel.cacTotal) },
    { rotulo: "LTV", fmt: (r) => formatBRL(r.unitEconomics.ltv), melhorMaior: true },
    { rotulo: "LTV/CAC", fmt: (r) => formatRatio(r.unitEconomics.ltvCac), melhorMaior: true },
    { rotulo: "Break-even carros", fmt: (r) => formatInt(r.breakEven.breakEvenCarros) },
    { rotulo: "Carros ativos", fmt: (r) => formatInt(r.fleet.carrosAtivos), melhorMaior: true },
    { rotulo: "Caixa mensal", fmt: (r) => formatBRL(r.cashFlow.caixaMensal), melhorMaior: true },
  ];

  return (
    <section className="rounded-2xl border border-surface-border bg-surface-card p-5">
      <h2 className="mb-3 text-sm font-semibold uppercase tracking-wide text-brand-400">
        Comparação de cenários
      </h2>
      <div className="overflow-x-auto">
        <table className="w-full min-w-[560px] border-collapse text-sm">
          <thead>
            <tr className="text-left text-slate-400">
              <th className="py-2 pr-4 font-medium">Indicador</th>
              {scenarioResults.map((s) => (
                <th key={s.id} className="py-2 pr-4 font-semibold text-slate-200">
                  {s.nome}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {linhas.map((l) => (
              <tr
                key={l.rotulo}
                className="border-t border-surface-border/40 text-slate-300"
              >
                <td className="py-2 pr-4 text-slate-400">{l.rotulo}</td>
                {scenarioResults.map((s) => (
                  <td
                    key={s.id}
                    className="py-2 pr-4 tabular-nums font-medium text-slate-100"
                  >
                    {l.fmt(s.result)}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="mt-3 text-[11px] text-slate-500">
        Os cenários usam as premissas padrão da eDrive Go com os respectivos overrides.
        Edite os campos acima para simular a partir do cenário selecionado.
      </p>
    </section>
  );
}
