"use client";

import { useCalculator } from "./CalculatorContext";
import { scenarioList } from "@/lib/scenarios";

/** Seletor de cenário (Conservador / Base / Agressivo / Stress). */
export default function ScenarioSelector() {
  const { scenarioId, setScenario } = useCalculator();

  return (
    <div className="flex flex-wrap items-center gap-2">
      <span className="mr-1 text-xs uppercase tracking-wide text-slate-400">
        Cenário:
      </span>
      {scenarioList.map((s) => {
        const ativo = s.id === scenarioId;
        return (
          <button
            key={s.id}
            type="button"
            onClick={() => setScenario(s.id)}
            title={s.descricao}
            className={`rounded-lg px-3 py-1.5 text-sm font-medium transition ${
              ativo
                ? "bg-brand-600 text-white shadow"
                : "border border-surface-border bg-surface-soft text-slate-300 hover:border-brand-600"
            }`}
          >
            {s.nome}
          </button>
        );
      })}
    </div>
  );
}
