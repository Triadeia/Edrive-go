"use client";

import NumberInput from "./NumberInput";

/**
 * SliderInput — rótulo + range slider + NumberInput sincronizados.
 * Escrever no slider ou no número atualiza o mesmo valor (fonte única).
 */
export default function SliderInput({
  label,
  valor,
  onChange,
  min,
  max,
  step = 1,
  prefixo,
  sufixo,
  dica,
  modoPercentual = false,
}: {
  label: string;
  valor: number;
  onChange: (v: number) => void;
  min: number;
  max: number;
  step?: number;
  prefixo?: string;
  sufixo?: string;
  dica?: string;
  /** Se true, o campo é uma fração (0..1) exibida como % no NumberInput. */
  modoPercentual?: boolean;
}) {
  // Em modo percentual, o NumberInput mostra 0..100 mas o valor real é 0..1.
  const valorExibido = modoPercentual ? valor * 100 : valor;
  const minExibido = modoPercentual ? min * 100 : min;
  const maxExibido = modoPercentual ? max * 100 : max;
  const stepExibido = modoPercentual ? step * 100 : step;

  const setDeExibido = (v: number) => onChange(modoPercentual ? v / 100 : v);

  return (
    <div>
      <div className="mb-1.5 flex items-center justify-between gap-3">
        <label className="text-sm text-slate-200">
          {label}
          {dica && (
            <span className="ml-1 text-[11px] text-slate-500" title={dica}>
              ⓘ
            </span>
          )}
        </label>
        <div className="w-32 shrink-0">
          <NumberInput
            valor={valorExibido}
            onChange={setDeExibido}
            step={stepExibido}
            min={minExibido}
            max={maxExibido}
            prefixo={prefixo}
            sufixo={modoPercentual ? "%" : sufixo}
            ariaLabel={label}
          />
        </div>
      </div>
      <input
        type="range"
        className="w-full"
        min={minExibido}
        max={maxExibido}
        step={stepExibido}
        value={valorExibido}
        onChange={(e) => setDeExibido(Number(e.target.value))}
        aria-label={`${label} (slider)`}
      />
    </div>
  );
}
