"use client";

import { useCalculator } from "./CalculatorContext";
import InputCard from "./InputCard";
import SliderInput from "./SliderInput";

/** Bloco ESTRUTURA / IMPOSTOS / FINANCEIRO. */
export default function StructureCalculator() {
  const { assumptions: a, setField } = useCalculator();

  return (
    <InputCard titulo="Estrutura & Impostos" descricao="Despesas fixas, impostos e caixa" icone="🧾">
      <SliderInput label="Impostos sobre receita" valor={a.impostosSobreReceita} onChange={(v) => setField("impostosSobreReceita", v)} min={0} max={0.4} step={0.005} modoPercentual />
      <SliderInput label="Impostos sobre lucro" valor={a.impostosSobreLucro} onChange={(v) => setField("impostosSobreLucro", v)} min={0} max={0.4} step={0.005} modoPercentual />
      <SliderInput label="Despesas administrativas/mês" valor={a.despesasAdministrativasMes} onChange={(v) => setField("despesasAdministrativasMes", v)} min={0} max={200000} step={1000} prefixo="R$" />
      <SliderInput label="Ferramentas / software" valor={a.ferramentasMes} onChange={(v) => setField("ferramentasMes", v)} min={0} max={50000} step={500} prefixo="R$" />
      <SliderInput label="Depreciação/mês" valor={a.depreciacaoMes} onChange={(v) => setField("depreciacaoMes", v)} min={0} max={100000} step={1000} prefixo="R$" />
      <SliderInput label="Resultado financeiro/mês" valor={a.resultadoFinanceiroMes} onChange={(v) => setField("resultadoFinanceiroMes", v)} min={-50000} max={50000} step={1000} prefixo="R$" />
      <SliderInput label="Caixa inicial" valor={a.caixaInicial} onChange={(v) => setField("caixaInicial", v)} min={0} max={2000000} step={10000} prefixo="R$" />
    </InputCard>
  );
}
