"use client";

import { useCalculator } from "./CalculatorContext";
import InputCard from "./InputCard";
import SliderInput from "./SliderInput";
import { formatInt, formatBRL } from "@/lib/formatters";

/** Bloco SUPORTE / OPERAÇÃO: atendimento e gestão de frota. */
export default function SupportCalculator() {
  const { assumptions: a, setField, result } = useCalculator();
  const s = result.supportTeam;

  return (
    <InputCard titulo="Suporte / Operação" descricao="Atendimento ao motorista e gestão de frota" icone="🛠️">
      <SliderInput label="Tickets por motorista/mês" valor={a.ticketsPorMotoristaMes} onChange={(v) => setField("ticketsPorMotoristaMes", v)} min={0} max={5} step={0.1} />
      <SliderInput label="Capacidade de tickets/atendente" valor={a.capacidadeTicketsPorAtendente} onChange={(v) => setField("capacidadeTicketsPorAtendente", v)} min={100} max={2000} step={50} />
      <SliderInput label="Salário atendente" valor={a.salarioAtendente} onChange={(v) => setField("salarioAtendente", v)} min={1000} max={8000} step={100} prefixo="R$" />
      <SliderInput label="Carros por gestor de frota" valor={a.carrosPorGestorFrota} onChange={(v) => setField("carrosPorGestorFrota", v)} min={10} max={200} step={5} />
      <SliderInput label="Salário gestor de frota" valor={a.salarioGestorFrota} onChange={(v) => setField("salarioGestorFrota", v)} min={2000} max={12000} step={100} prefixo="R$" />
      <SliderInput label="Custo de recuperação de veículo" valor={a.custoRecuperacaoVeiculo} onChange={(v) => setField("custoRecuperacaoVeiculo", v)} min={0} max={3000} step={50} prefixo="R$" />

      <div className="mt-2 grid grid-cols-3 gap-2 rounded-lg bg-surface-soft p-3 text-center text-xs">
        <div><div className="text-slate-400">Atendentes</div><div className="font-semibold text-slate-100">{formatInt(s.atendentes)}</div></div>
        <div><div className="text-slate-400">Gestores</div><div className="font-semibold text-slate-100">{formatInt(s.gestoresFrota)}</div></div>
        <div><div className="text-slate-400">Folha</div><div className="font-semibold text-slate-100">{formatBRL(s.custoSuporteTotal)}</div></div>
      </div>
    </InputCard>
  );
}
