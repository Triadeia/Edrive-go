"use client";

import { useCalculator } from "./CalculatorContext";
import InputCard from "./InputCard";
import SliderInput from "./SliderInput";
import { formatInt, formatBRL } from "@/lib/formatters";

/** Bloco VENDAS: produtividade e salários da equipe comercial. */
export default function TeamCalculator() {
  const { assumptions: a, setField, result } = useCalculator();
  const team = result.salesTeam;

  return (
    <InputCard titulo="Vendas" descricao="Dimensionamento da equipe comercial (teto)" icone="🧑‍💼">
      <SliderInput label="Leads por SDR/mês" valor={a.leadsPorSDRMes} onChange={(v) => setField("leadsPorSDRMes", v)} min={50} max={1000} step={10} />
      <SliderInput label="Oportunidades por closer/mês" valor={a.oportunidadesPorCloserMes} onChange={(v) => setField("oportunidadesPorCloserMes", v)} min={20} max={400} step={5} />
      <SliderInput label="Entregas por operador/mês" valor={a.entregasPorOperadorMes} onChange={(v) => setField("entregasPorOperadorMes", v)} min={5} max={200} step={5} />
      <SliderInput label="Aplicações por analista/mês" valor={a.aplicacoesPorAnalistaMes} onChange={(v) => setField("aplicacoesPorAnalistaMes", v)} min={50} max={800} step={10} />
      <SliderInput label="Salário SDR" valor={a.salarioSDR} onChange={(v) => setField("salarioSDR", v)} min={1000} max={8000} step={100} prefixo="R$" />
      <SliderInput label="Salário closer" valor={a.salarioCloser} onChange={(v) => setField("salarioCloser", v)} min={1500} max={12000} step={100} prefixo="R$" />
      <SliderInput label="Salário operador" valor={a.salarioOperador} onChange={(v) => setField("salarioOperador", v)} min={1000} max={8000} step={100} prefixo="R$" />
      <SliderInput label="Salário analista" valor={a.salarioAnalista} onChange={(v) => setField("salarioAnalista", v)} min={1500} max={10000} step={100} prefixo="R$" />
      <SliderInput label="Salário gerente comercial" valor={a.salarioGerenteComercial} onChange={(v) => setField("salarioGerenteComercial", v)} min={3000} max={20000} step={250} prefixo="R$" />
      <SliderInput label="Comissão por contrato" valor={a.comissaoPorContrato} onChange={(v) => setField("comissaoPorContrato", v)} min={0} max={2000} step={50} prefixo="R$" />

      <div className="mt-2 grid grid-cols-3 gap-2 rounded-lg bg-surface-soft p-3 text-center text-xs">
        <div><div className="text-slate-400">SDRs</div><div className="font-semibold text-slate-100">{formatInt(team.sdrs)}</div></div>
        <div><div className="text-slate-400">Closers</div><div className="font-semibold text-slate-100">{formatInt(team.closers)}</div></div>
        <div><div className="text-slate-400">Operadores</div><div className="font-semibold text-slate-100">{formatInt(team.operadores)}</div></div>
        <div><div className="text-slate-400">Analistas</div><div className="font-semibold text-slate-100">{formatInt(team.analistas)}</div></div>
        <div><div className="text-slate-400">Gerentes</div><div className="font-semibold text-slate-100">{formatInt(team.gerentes)}</div></div>
        <div><div className="text-slate-400">Folha+com.</div><div className="font-semibold text-slate-100">{formatBRL(team.custoComercialTotal)}</div></div>
      </div>
    </InputCard>
  );
}
