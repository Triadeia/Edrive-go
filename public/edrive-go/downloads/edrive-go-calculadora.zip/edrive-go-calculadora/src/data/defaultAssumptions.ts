import type { Assumptions } from "@/types/business";

/**
 * Premissas padrão — CENÁRIO BASE da eDrive Go.
 * Estes valores são o ponto de partida; todos são editáveis pela UI.
 */
export const defaultAssumptions: Assumptions = {
  // ---------- FROTA ----------
  totalCarros: 100,
  custoAluguelVeiculoMes: 2800,
  seguroMes: 0,
  telemetriaMes: 45,
  manutencaoMes: 150,
  pneusMes: 60,
  lavagemMes: 80,
  patioAdminMes: 120,
  pctCarrosParados: 0.08,
  pctSinistroMes: 0.015,
  custoSinistroMedio: 2500,
  taxaOcupacao: 0.92,

  // ---------- OFERTA AO MOTORISTA ----------
  valorMensalMotorista: 3900,
  valorSemanalMotorista: 900,
  valorDiaMotorista: 150,
  taxaAtivacao: 300,
  entradaSinalCaucao: 500,
  churnMensal: 0.06,
  inadimplenciaMensal: 0.07,
  pctRecuperacaoInadimplencia: 0.5,
  prazoMedioContratoMeses: 12,

  // ---------- MARKETING / FUNIL ----------
  cpl: 20,
  investimentoMarketingMes: 30000,
  taxaLeadParaGrupo: 0.5,
  taxaGrupoParaWebinar: 0.35,
  taxaComparecimento: 0.5,
  taxaAplicacao: 0.4,
  taxaAprovacao: 0.5,
  taxaFechamento: 0.4,

  // ---------- VENDAS / EQUIPE ----------
  leadsPorSDRMes: 400,
  oportunidadesPorCloserMes: 120,
  entregasPorOperadorMes: 40,
  aplicacoesPorAnalistaMes: 250,
  salarioSDR: 2500,
  salarioCloser: 3500,
  comissaoPorContrato: 200,
  salarioGerenteComercial: 8000,

  // ---------- SUPORTE / OPERAÇÃO ----------
  salarioAtendente: 2500,
  carrosPorGestorFrota: 60,
  salarioGestorFrota: 4000,
  salarioOperador: 2500,
  salarioAnalista: 3000,
  ticketsPorMotoristaMes: 1.2,
  capacidadeTicketsPorAtendente: 700,
  custoRecuperacaoVeiculo: 400,

  // ---------- CRÉDITO / CONSÓRCIO ----------
  pctInteressadosConsorcio: 0.2,
  taxaConversaoConsorcio: 0.15,
  comissaoMediaConsorcio: 1200,
  ticketMedioCarta: 90000,
  pctCancelamentoConsorcio: 0.15,
  custoCompliancePorOp: 100,

  // ---------- IMPOSTOS / ESTRUTURA / FINANCEIRO ----------
  impostosSobreReceita: 0.15,
  impostosSobreLucro: 0.0,
  despesasAdministrativasMes: 25000,
  ferramentasMes: 5000,
  depreciacaoMes: 0,
  resultadoFinanceiroMes: 0,
  caixaInicial: 300000,
};
