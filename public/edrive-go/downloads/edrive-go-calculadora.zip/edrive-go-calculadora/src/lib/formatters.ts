/**
 * Utilitários de formatação em pt-BR.
 * São funções puras, sem efeitos colaterais.
 */

/** Formata como moeda BRL (R$). */
export function formatBRL(valor: number): string {
  if (!isFinite(valor)) return "—";
  return new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: "BRL",
    maximumFractionDigits: 0,
  }).format(valor);
}

/** Formata como moeda BRL com centavos. */
export function formatBRLCentavos(valor: number): string {
  if (!isFinite(valor)) return "—";
  return new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: "BRL",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(valor);
}

/** Formata uma fração (0..1) como percentual. */
export function formatPct(fracao: number, casas = 1): string {
  if (!isFinite(fracao)) return "—";
  return new Intl.NumberFormat("pt-BR", {
    style: "percent",
    minimumFractionDigits: casas,
    maximumFractionDigits: casas,
  }).format(fracao);
}

/** Formata número inteiro (arredondado). */
export function formatInt(valor: number): string {
  if (!isFinite(valor)) return "—";
  return new Intl.NumberFormat("pt-BR", {
    maximumFractionDigits: 0,
  }).format(Math.round(valor));
}

/** Formata número com casas decimais. */
export function formatNum(valor: number, casas = 2): string {
  if (!isFinite(valor)) return "—";
  return new Intl.NumberFormat("pt-BR", {
    minimumFractionDigits: casas,
    maximumFractionDigits: casas,
  }).format(valor);
}

/** Formata razão (ex.: LTV/CAC) como "x,xx". */
export function formatRatio(valor: number): string {
  if (!isFinite(valor)) return "—";
  return `${formatNum(valor, 2)}x`;
}
