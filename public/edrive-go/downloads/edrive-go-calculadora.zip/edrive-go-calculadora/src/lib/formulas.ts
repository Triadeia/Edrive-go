/**
 * formulas.ts — Fórmulas ATÔMICAS e puras do modelo eDrive Go.
 *
 * Cada função implementa EXATAMENTE uma fórmula do enunciado.
 * Ficam separadas da engine (calculationEngine.ts) para serem testáveis isoladamente.
 * Nada aqui acessa DOM, localStorage ou URL — apenas matemática.
 */

/** Divisão segura: retorna 0 quando o denominador é 0 (evita NaN/Infinity). */
export function safeDiv(numerador: number, denominador: number): number {
  if (!denominador || !isFinite(denominador)) return 0;
  return numerador / denominador;
}

// ---------- FROTA ----------

/**
 * carros_ativos = totalCarros * taxaOcupacao * (1 - pctCarrosParados)
 */
export function carrosAtivos(
  totalCarros: number,
  taxaOcupacao: number,
  pctCarrosParados: number
): number {
  return totalCarros * taxaOcupacao * (1 - pctCarrosParados);
}

/**
 * custo_frota = totalCarros * (soma dos custos fixos por carro)
 *             + (pctSinistroMes * totalCarros * custoSinistroMedio)
 */
export function custoFrota(params: {
  totalCarros: number;
  custoAluguelVeiculoMes: number;
  seguroMes: number;
  telemetriaMes: number;
  manutencaoMes: number;
  pneusMes: number;
  lavagemMes: number;
  patioAdminMes: number;
  pctSinistroMes: number;
  custoSinistroMedio: number;
}): number {
  const custoFixoPorCarro =
    params.custoAluguelVeiculoMes +
    params.seguroMes +
    params.telemetriaMes +
    params.manutencaoMes +
    params.pneusMes +
    params.lavagemMes +
    params.patioAdminMes;

  const custoOperacional = params.totalCarros * custoFixoPorCarro;
  const custoSinistro =
    params.pctSinistroMes * params.totalCarros * params.custoSinistroMedio;

  return custoOperacional + custoSinistro;
}

// ---------- RECEITA ----------

/**
 * receita_mensal_frota = carros_ativos * valorMensalMotorista
 */
export function receitaMensalFrota(
  carrosAtivos: number,
  valorMensalMotorista: number
): number {
  return carrosAtivos * valorMensalMotorista;
}

/**
 * receita_ativacao = novosContratos * taxaAtivacao
 */
export function receitaAtivacao(novosContratos: number, taxaAtivacao: number): number {
  return novosContratos * taxaAtivacao;
}

/**
 * receita_bruta = receita_mensal_frota + receita_ativacao + receita_complementar
 */
export function receitaBruta(
  receitaMensalFrota: number,
  receitaAtivacao: number,
  receitaComplementar: number
): number {
  return receitaMensalFrota + receitaAtivacao + receitaComplementar;
}

/**
 * deducoes = receita_bruta * impostosSobreReceita
 */
export function deducoes(receitaBruta: number, impostosSobreReceita: number): number {
  return receitaBruta * impostosSobreReceita;
}

/**
 * receita_liquida = receita_bruta - deducoes
 */
export function receitaLiquida(receitaBruta: number, deducoes: number): number {
  return receitaBruta - deducoes;
}

/**
 * perda_inadimplencia = receita_mensal_frota * inadimplenciaMensal
 *                       * (1 - pctRecuperacaoInadimplencia)
 */
export function perdaInadimplencia(
  receitaMensalFrota: number,
  inadimplenciaMensal: number,
  pctRecuperacaoInadimplencia: number
): number {
  return (
    receitaMensalFrota * inadimplenciaMensal * (1 - pctRecuperacaoInadimplencia)
  );
}

// ---------- FUNIL DE MARKETING ----------

/**
 * leads_gerados = investimentoMarketingMes / cpl
 */
export function leadsGerados(investimentoMarketingMes: number, cpl: number): number {
  return safeDiv(investimentoMarketingMes, cpl);
}

/**
 * participantes_webinar = leads_gerados * taxaLeadParaGrupo
 *                         * taxaGrupoParaWebinar * taxaComparecimento
 */
export function participantesWebinar(params: {
  leadsGerados: number;
  taxaLeadParaGrupo: number;
  taxaGrupoParaWebinar: number;
  taxaComparecimento: number;
}): number {
  return (
    params.leadsGerados *
    params.taxaLeadParaGrupo *
    params.taxaGrupoParaWebinar *
    params.taxaComparecimento
  );
}

/** aplicacoes = participantes_webinar * taxaAplicacao */
export function aplicacoes(participantesWebinar: number, taxaAplicacao: number): number {
  return participantesWebinar * taxaAplicacao;
}

/** aprovados = aplicacoes * taxaAprovacao */
export function aprovados(aplicacoes: number, taxaAprovacao: number): number {
  return aplicacoes * taxaAprovacao;
}

/** contratos = aprovados * taxaFechamento */
export function contratos(aprovados: number, taxaFechamento: number): number {
  return aprovados * taxaFechamento;
}

/** CAC_marketing = investimentoMarketingMes / contratos */
export function cacMarketing(
  investimentoMarketingMes: number,
  contratos: number
): number {
  return safeDiv(investimentoMarketingMes, contratos);
}

/**
 * CAC_total = (investimentoMarketingMes + salariosComerciais + comissoes) / contratos
 */
export function cacTotal(params: {
  investimentoMarketingMes: number;
  salariosComerciais: number;
  comissoes: number;
  contratos: number;
}): number {
  return safeDiv(
    params.investimentoMarketingMes + params.salariosComerciais + params.comissoes,
    params.contratos
  );
}

// ---------- DIMENSIONAMENTO DE EQUIPE (teto = Math.ceil) ----------

/** SDRs = ceil(leads_gerados / leadsPorSDRMes) */
export function numSDRs(leadsGerados: number, leadsPorSDRMes: number): number {
  return Math.ceil(safeDiv(leadsGerados, leadsPorSDRMes));
}

/** closers = ceil(aplicacoes / oportunidadesPorCloserMes) */
export function numClosers(
  aplicacoes: number,
  oportunidadesPorCloserMes: number
): number {
  return Math.ceil(safeDiv(aplicacoes, oportunidadesPorCloserMes));
}

/**
 * atendentes = ceil((carros_ativos * ticketsPorMotoristaMes) / capacidadeTicketsPorAtendente)
 */
export function numAtendentes(params: {
  carrosAtivos: number;
  ticketsPorMotoristaMes: number;
  capacidadeTicketsPorAtendente: number;
}): number {
  return Math.ceil(
    safeDiv(
      params.carrosAtivos * params.ticketsPorMotoristaMes,
      params.capacidadeTicketsPorAtendente
    )
  );
}

/** gestores_frota = ceil(totalCarros / carrosPorGestorFrota) */
export function numGestoresFrota(
  totalCarros: number,
  carrosPorGestorFrota: number
): number {
  return Math.ceil(safeDiv(totalCarros, carrosPorGestorFrota));
}

/** operadores = ceil(contratos / entregasPorOperadorMes) */
export function numOperadores(
  contratos: number,
  entregasPorOperadorMes: number
): number {
  return Math.ceil(safeDiv(contratos, entregasPorOperadorMes));
}

/** analistas = ceil(aplicacoes / aplicacoesPorAnalistaMes) */
export function numAnalistas(
  aplicacoes: number,
  aplicacoesPorAnalistaMes: number
): number {
  return Math.ceil(safeDiv(aplicacoes, aplicacoesPorAnalistaMes));
}

// ---------- DRE ----------

/** margem_bruta = receita_liquida - custo_frota - perda_inadimplencia */
export function margemBruta(
  receitaLiquida: number,
  custoFrota: number,
  perdaInadimplencia: number
): number {
  return receitaLiquida - custoFrota - perdaInadimplencia;
}

/**
 * EBITDA = margem_bruta - despesasMarketing - despesasComerciais
 *          - despesasOperacionais - despesasAdministrativas
 */
export function ebitda(params: {
  margemBruta: number;
  despesasMarketing: number;
  despesasComerciais: number;
  despesasOperacionais: number;
  despesasAdministrativas: number;
}): number {
  return (
    params.margemBruta -
    params.despesasMarketing -
    params.despesasComerciais -
    params.despesasOperacionais -
    params.despesasAdministrativas
  );
}

/**
 * lucro_liquido = EBITDA - depreciacao - resultadoFinanceiro - impostosSobreLucro
 */
export function lucroLiquido(params: {
  ebitda: number;
  depreciacao: number;
  resultadoFinanceiro: number;
  impostosSobreLucro: number;
}): number {
  return (
    params.ebitda -
    params.depreciacao -
    params.resultadoFinanceiro -
    params.impostosSobreLucro
  );
}

// ---------- UNIT ECONOMICS ----------

/**
 * margem_contribuicao_por_carro =
 *   valorMensalMotorista * (1 - impostosSobreReceita)
 *   * (1 - inadimplenciaMensal * (1 - pctRecuperacaoInadimplencia))
 *   - custoFrotaPorCarro
 */
export function margemContribuicaoPorCarro(params: {
  valorMensalMotorista: number;
  impostosSobreReceita: number;
  inadimplenciaMensal: number;
  pctRecuperacaoInadimplencia: number;
  custoFrotaPorCarro: number;
}): number {
  const receitaLiquidaPorCarro =
    params.valorMensalMotorista *
    (1 - params.impostosSobreReceita) *
    (1 -
      params.inadimplenciaMensal * (1 - params.pctRecuperacaoInadimplencia));

  return receitaLiquidaPorCarro - params.custoFrotaPorCarro;
}

/** break_even_carros = despesasFixasTotais / margem_contribuicao_por_carro */
export function breakEvenCarros(
  despesasFixasTotais: number,
  margemContribuicaoPorCarro: number
): number {
  return safeDiv(despesasFixasTotais, margemContribuicaoPorCarro);
}

/** LTV = margemMensalPorMotorista * (1 / churnMensal)  — vida média = 1/churn */
export function ltv(margemMensalPorMotorista: number, churnMensal: number): number {
  return margemMensalPorMotorista * safeDiv(1, churnMensal);
}

/** LTV_CAC = LTV / CAC_total */
export function ltvCac(ltv: number, cacTotal: number): number {
  return safeDiv(ltv, cacTotal);
}

/** payback_CAC_meses = CAC_total / margemMensalPorMotorista */
export function paybackCacMeses(
  cacTotal: number,
  margemMensalPorMotorista: number
): number {
  return safeDiv(cacTotal, margemMensalPorMotorista);
}
