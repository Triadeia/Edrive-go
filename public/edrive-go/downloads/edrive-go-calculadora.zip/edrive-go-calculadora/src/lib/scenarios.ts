import type { Scenario, ScenarioId } from "@/types/calculator";

/**
 * Definição dos 4 cenários.
 * A base é o defaultAssumptions (sem overrides); os demais aplicam overrides sobre ela.
 */
export const scenarios: Record<ScenarioId, Scenario> = {
  base: {
    id: "base",
    nome: "Base",
    descricao: "Cenário central com premissas realistas de operação.",
    overrides: {},
  },
  conservador: {
    id: "conservador",
    nome: "Conservador",
    descricao: "Aquisição mais cara, ocupação e fechamento menores, inadimplência maior.",
    overrides: {
      cpl: 35,
      taxaFechamento: 0.3,
      custoAluguelVeiculoMes: 3200,
      inadimplenciaMensal: 0.12,
      taxaOcupacao: 0.82,
      churnMensal: 0.09,
      valorMensalMotorista: 3600,
    },
  },
  agressivo: {
    id: "agressivo",
    nome: "Agressivo",
    descricao: "Aquisição barata, ocupação alta, churn e inadimplência baixos.",
    overrides: {
      cpl: 12,
      taxaFechamento: 0.5,
      custoAluguelVeiculoMes: 2500,
      inadimplenciaMensal: 0.04,
      taxaOcupacao: 0.95,
      churnMensal: 0.04,
      valorMensalMotorista: 4100,
      taxaConversaoConsorcio: 0.22,
    },
  },
  stress: {
    id: "stress",
    nome: "Stress",
    descricao: "Choque adverso: mídia cara, ocupação baixa, sinistros e inadimplência altos.",
    overrides: {
      cpl: 60,
      taxaFechamento: 0.25,
      custoAluguelVeiculoMes: 3400,
      inadimplenciaMensal: 0.18,
      taxaOcupacao: 0.7,
      churnMensal: 0.12,
      pctCarrosParados: 0.15,
      pctSinistroMes: 0.04,
    },
  },
};

/** Lista ordenada de cenários para exibição na UI. */
export const scenarioList: Scenario[] = [
  scenarios.conservador,
  scenarios.base,
  scenarios.agressivo,
  scenarios.stress,
];
