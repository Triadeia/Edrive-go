/**
 * validations.ts — regras de negócio que geram alertas.
 * Função pura: recebe premissas + resultado calculado e devolve lista de alertas.
 */

import type { Assumptions } from "@/types/business";
import type { CalculationResult, ValidationAlert } from "@/types/calculator";

/**
 * validateAssumptions — retorna array de alertas {campo, severidade, mensagem}.
 *
 * Regras (do enunciado):
 *  - CPL > 50
 *  - taxaFechamento < 0.25
 *  - margem_contribuicao_por_carro < 0 (perigo)
 *  - taxaOcupacao < 0.80
 *  - inadimplenciaMensal > 0.10
 *  - LTV_CAC < 3
 *  - break_even_carros > totalCarros
 */
export function validateAssumptions(
  a: Assumptions,
  result: CalculationResult
): ValidationAlert[] {
  const alerts: ValidationAlert[] = [];

  if (a.cpl > 50) {
    alerts.push({
      campo: "cpl",
      severidade: "aviso",
      mensagem: `CPL de R$ ${a.cpl.toFixed(0)} está alto (acima de R$ 50). Aquisição encarece e pressiona o CAC.`,
    });
  }

  if (a.taxaFechamento < 0.25) {
    alerts.push({
      campo: "taxaFechamento",
      severidade: "aviso",
      mensagem: `Taxa de fechamento de ${(a.taxaFechamento * 100).toFixed(0)}% está baixa (abaixo de 25%). Revise a qualificação e o time comercial.`,
    });
  }

  if (result.unitEconomics.margemContribuicaoPorCarro < 0) {
    alerts.push({
      campo: "margemContribuicaoPorCarro",
      severidade: "perigo",
      mensagem:
        "Aluguel da locadora > receita líquida por carro — renegocie o aluguel, aumente o preço ao motorista ou aumente ocupação",
    });
  }

  if (a.taxaOcupacao < 0.8) {
    alerts.push({
      campo: "taxaOcupacao",
      severidade: "aviso",
      mensagem: `Ocupação de ${(a.taxaOcupacao * 100).toFixed(0)}% está abaixo de 80%. Carros ociosos custam aluguel sem gerar receita.`,
    });
  }

  if (a.inadimplenciaMensal > 0.1) {
    alerts.push({
      campo: "inadimplenciaMensal",
      severidade: "perigo",
      mensagem: `Inadimplência de ${(a.inadimplenciaMensal * 100).toFixed(0)}% está acima de 10%. Reforce análise de crédito e cobrança.`,
    });
  }

  if (result.unitEconomics.ltvCac < 3) {
    alerts.push({
      campo: "ltvCac",
      severidade: "aviso",
      mensagem: `LTV/CAC de ${result.unitEconomics.ltvCac.toFixed(2)}x está abaixo de 3x. A economia de aquisição está apertada.`,
    });
  }

  if (result.breakEven.breakEvenCarros > a.totalCarros) {
    alerts.push({
      campo: "breakEvenCarros",
      severidade: "perigo",
      mensagem: `Break-even de ${Math.ceil(
        result.breakEven.breakEvenCarros
      )} carros é maior que a frota de ${a.totalCarros}. A operação não empata com a frota atual.`,
    });
  }

  return alerts;
}
