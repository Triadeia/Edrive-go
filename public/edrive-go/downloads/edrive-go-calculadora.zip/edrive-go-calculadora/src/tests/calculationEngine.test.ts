import { describe, it, expect } from "vitest";
import {
  calculate,
  calculateFleetCosts,
  calculateMarketingFunnel,
  calculateSalesTeam,
  calculateScenarios,
  buildAssumptions,
} from "@/lib/calculationEngine";
import { validateAssumptions } from "@/lib/validations";
import { defaultAssumptions } from "@/data/defaultAssumptions";
import { scenarios } from "@/lib/scenarios";

const base = defaultAssumptions;

describe("calculationEngine — engine composta", () => {
  it("1. fleet costs: carros ativos e custo da frota no cenário base", () => {
    const fleet = calculateFleetCosts(base);
    expect(fleet.carrosAtivos).toBeCloseTo(84.64, 2);
    expect(fleet.custoFrota).toBe(329250);
    expect(fleet.custoFrotaPorCarro).toBeCloseTo(3292.5, 2);
  });

  it("2. funil de marketing: leads -> contratos", () => {
    const f = calculateMarketingFunnel(base);
    expect(f.leadsGerados).toBe(1500);
    // 1500 * 0.5 * 0.35 * 0.5 = 131.25 participantes
    expect(f.participantesWebinar).toBeCloseTo(131.25, 3);
    // aplicacoes = 131.25 * 0.4 = 52.5
    expect(f.aplicacoes).toBeCloseTo(52.5, 3);
    // aprovados = 52.5 * 0.5 = 26.25
    expect(f.aprovados).toBeCloseTo(26.25, 3);
    // contratos = 26.25 * 0.4 = 10.5
    expect(f.contratos).toBeCloseTo(10.5, 3);
  });

  it("3. CAC total é maior que CAC de marketing (inclui folha comercial)", () => {
    const r = calculate(base);
    expect(r.funnel.cacTotal).toBeGreaterThan(r.funnel.cacMarketing);
  });

  it("4. dimensionamento de equipe usa teto (ceil)", () => {
    const f = calculateMarketingFunnel(base);
    const team = calculateSalesTeam(base, f);
    // leads 1500 / 400 = 3.75 -> 4
    expect(team.sdrs).toBe(4);
    // aplicacoes 52.5 / 120 -> 1
    expect(team.closers).toBe(1);
    // contratos 10.5 / 40 -> 1
    expect(team.operadores).toBe(1);
    // aplicacoes 52.5 / 250 -> 1
    expect(team.analistas).toBe(1);
  });

  it("5. suporte: atendentes e gestores por teto", () => {
    const r = calculate(base);
    // gestores = ceil(100/60) = 2
    expect(r.supportTeam.gestoresFrota).toBe(2);
    // atendentes = ceil(84.64 * 1.2 / 700) = ceil(0.145) = 1
    expect(r.supportTeam.atendentes).toBe(1);
  });

  it("6. DRE fecha: receita_liquida - custo_frota - inadimplencia = margem_bruta", () => {
    const r = calculate(base);
    const esperado =
      r.dre.receitaLiquida - r.dre.custoFrota - r.dre.perdaInadimplencia;
    expect(r.dre.margemBruta).toBeCloseTo(esperado, 6);
  });

  it("7. DRE: receita_liquida = receita_bruta - deducoes", () => {
    const r = calculate(base);
    expect(r.dre.receitaLiquida).toBeCloseTo(
      r.dre.receitaBruta - r.dre.deducoes,
      6
    );
  });

  it("8. EBITDA = margem_bruta menos os quatro buckets de despesa", () => {
    const r = calculate(base);
    const esperado =
      r.dre.margemBruta -
      r.dre.despesasMarketing -
      r.dre.despesasComerciais -
      r.dre.despesasOperacionais -
      r.dre.despesasAdministrativas;
    expect(r.dre.ebitda).toBeCloseTo(esperado, 6);
  });

  it("9. unit economics: LTV = margem * (1/churn) e payback coerente", () => {
    const r = calculate(base);
    const u = r.unitEconomics;
    expect(u.vidaMediaMeses).toBeCloseTo(1 / base.churnMensal, 6);
    expect(u.ltv).toBeCloseTo(u.margemMensalPorMotorista / base.churnMensal, 4);
    if (u.margemMensalPorMotorista !== 0) {
      expect(u.paybackCacMeses).toBeCloseTo(
        u.cacTotal / u.margemMensalPorMotorista,
        4
      );
    }
  });

  it("10. unit economics: LTV/CAC = LTV / CAC_total", () => {
    const r = calculate(base);
    const u = r.unitEconomics;
    expect(u.ltvCac).toBeCloseTo(u.ltv / u.cacTotal, 6);
  });

  it("11. break-even: usa margem de contribuição por carro e despesas fixas", () => {
    const r = calculate(base);
    const bec =
      r.breakEven.despesasFixasTotais /
      r.breakEven.margemContribuicaoPorCarro;
    expect(r.breakEven.breakEvenCarros).toBeCloseTo(bec, 6);
  });

  it("12. cenário Stress produz EBITDA menor que o Base", () => {
    const rs = calculateScenarios(base);
    const ebitdaBase = rs.find((s) => s.id === "base")!.result.dre.ebitda;
    const ebitdaStress = rs.find((s) => s.id === "stress")!.result.dre.ebitda;
    expect(ebitdaStress).toBeLessThan(ebitdaBase);
  });

  it("13. cenário Agressivo produz EBITDA maior que o Base", () => {
    const rs = calculateScenarios(base);
    const ebitdaBase = rs.find((s) => s.id === "base")!.result.dre.ebitda;
    const ebitdaAgr = rs.find((s) => s.id === "agressivo")!.result.dre.ebitda;
    expect(ebitdaAgr).toBeGreaterThan(ebitdaBase);
  });

  it("14. validações: margem negativa gera alerta de perigo", () => {
    // Aumenta o aluguel para tornar a margem por carro negativa.
    const a = buildAssumptions(base, { custoAluguelVeiculoMes: 5000 });
    const r = calculate(a);
    const alerts = validateAssumptions(a, r);
    const perigo = alerts.find(
      (x) => x.campo === "margemContribuicaoPorCarro"
    );
    expect(perigo).toBeDefined();
    expect(perigo!.severidade).toBe("perigo");
  });

  it("15. cash flow: caixa_final = caixa_inicial + caixa_mensal", () => {
    const r = calculate(base);
    expect(r.cashFlow.caixaFinal).toBeCloseTo(
      r.cashFlow.caixaInicial + r.cashFlow.caixaMensal,
      4
    );
  });

  it("16. overrides do cenário Conservador reduzem receita bruta vs Base", () => {
    const rBase = calculate(base);
    const rCons = calculate(
      buildAssumptions(base, scenarios.conservador.overrides)
    );
    expect(rCons.offer.receitaBruta).toBeLessThan(rBase.offer.receitaBruta);
  });
});
