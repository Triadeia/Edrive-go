import { describe, it, expect } from "vitest";
import * as F from "@/lib/formulas";

describe("formulas — fórmulas atômicas", () => {
  it("carros_ativos aplica ocupação e carros parados", () => {
    // 100 * 0.92 * (1 - 0.08) = 84.64
    expect(F.carrosAtivos(100, 0.92, 0.08)).toBeCloseTo(84.64, 5);
  });

  it("custo_frota soma custos fixos por carro + sinistro esperado", () => {
    // custo fixo por carro = 2800+0+45+150+60+80+120 = 3255
    // operacional = 100 * 3255 = 325500
    // sinistro = 0.015 * 100 * 2500 = 3750
    // total = 329250
    const total = F.custoFrota({
      totalCarros: 100,
      custoAluguelVeiculoMes: 2800,
      seguroMes: 0,
      telemetriaMes: 45,
      manutencaoMes: 150,
      pneusMes: 60,
      lavagemMes: 80,
      patioAdminMes: 120,
      pctSinistroMes: 0.015,
      custoSinistroMedio: 2500,
    });
    expect(total).toBe(329250);
  });

  it("leads_gerados = investimento / cpl", () => {
    expect(F.leadsGerados(30000, 20)).toBe(1500);
  });

  it("participantes_webinar aplica as três taxas em cadeia", () => {
    // 1500 * 0.5 * 0.35 * 0.5 = 131.25
    expect(
      F.participantesWebinar({
        leadsGerados: 1500,
        taxaLeadParaGrupo: 0.5,
        taxaGrupoParaWebinar: 0.35,
        taxaComparecimento: 0.5,
      })
    ).toBeCloseTo(131.25, 5);
  });

  it("dimensionamento de equipe usa Math.ceil", () => {
    // 1500 / 400 = 3.75 -> ceil = 4
    expect(F.numSDRs(1500, 400)).toBe(4);
    // 52.5 / 120 = 0.4375 -> ceil = 1
    expect(F.numClosers(52.5, 120)).toBe(1);
  });

  it("margem_contribuicao_por_carro desconta imposto, inadimplência e custo", () => {
    // 3900 * (1-0.15) * (1 - 0.07*(1-0.5)) - custoFrotaPorCarro(3292.5)
    // 3900 * 0.85 * 0.965 - 3292.5 = 3198.975 - 3292.5 = -93.525
    const mc = F.margemContribuicaoPorCarro({
      valorMensalMotorista: 3900,
      impostosSobreReceita: 0.15,
      inadimplenciaMensal: 0.07,
      pctRecuperacaoInadimplencia: 0.5,
      custoFrotaPorCarro: 3292.5,
    });
    expect(mc).toBeCloseTo(-93.525, 3);
  });

  it("LTV usa vida média = 1/churn", () => {
    // margem 500, churn 0.05 -> 500 * (1/0.05) = 10000
    expect(F.ltv(500, 0.05)).toBe(10000);
  });

  it("safeDiv evita divisão por zero", () => {
    expect(F.safeDiv(10, 0)).toBe(0);
    expect(F.safeDiv(10, 2)).toBe(5);
  });
});
