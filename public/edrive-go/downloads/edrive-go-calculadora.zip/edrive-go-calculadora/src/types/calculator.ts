/**
 * Tipos de RESULTADO da engine de cálculo.
 * Todos os objetos retornados pelas funções puras estão tipados aqui.
 */

/** Custos da frota (calculateFleetCosts). */
export interface FleetCosts {
  carrosAtivos: number; // carros efetivamente gerando receita
  carrosParados: number; // carros parados (pátio/manutenção)
  custoOperacionalPorCarro: number; // custo fixo operacional por carro/mês (R$)
  custoOperacionalTotal: number; // custo operacional de toda a frota (R$)
  custoSinistroTotal: number; // custo esperado de sinistros no mês (R$)
  custoFrota: number; // custo total da frota (operacional + sinistro) (R$)
  custoFrotaPorCarro: number; // custo total da frota dividido por totalCarros (R$)
}

/** Receita da oferta ao motorista (calculateOfferRevenue). */
export interface OfferRevenue {
  carrosAtivos: number;
  novosContratos: number; // novos contratos no mês (vindos do funil)
  receitaMensalFrota: number; // mensalidades dos motoristas ativos (R$)
  receitaAtivacao: number; // taxas de ativação dos novos contratos (R$)
  receitaComplementar: number; // receita de crédito/consórcio (R$)
  receitaBruta: number; // receita bruta total (R$)
  deducoes: number; // impostos sobre receita (R$)
  receitaLiquida: number; // receita líquida (R$)
}

/** Funil de marketing (calculateMarketingFunnel). */
export interface MarketingFunnel {
  leadsGerados: number;
  participantesWebinar: number;
  aplicacoes: number;
  aprovados: number;
  contratos: number;
  cacMarketing: number; // CAC só com mídia (R$)
  cacTotal: number; // CAC com mídia + comercial (R$)
  investimentoMarketingMes: number;
}

/** Dimensionamento da equipe comercial (calculateSalesTeam). */
export interface SalesTeam {
  sdrs: number;
  closers: number;
  operadores: number;
  analistas: number;
  gerentes: number;
  salariosComerciais: number; // folha comercial total (R$)
  comissoes: number; // comissões totais (R$)
  custoComercialTotal: number; // folha + comissões (R$)
}

/** Dimensionamento da equipe de suporte/operação (calculateSupportTeam). */
export interface SupportTeam {
  atendentes: number;
  gestoresFrota: number;
  custoSuporteTotal: number; // folha de suporte/operação de frota (R$)
}

/** Receita de crédito/consórcio (calculateCreditRevenue). */
export interface CreditRevenue {
  interessados: number;
  cartasVendidas: number;
  receitaConsorcio: number; // comissões líquidas de consórcio (R$)
  custoCompliance: number; // custo de compliance total (R$)
  receitaLiquidaConsorcio: number; // receita de consórcio menos compliance (R$)
}

/** Demonstração de Resultado (calculateDRE). */
export interface DRE {
  receitaBruta: number;
  deducoes: number;
  receitaLiquida: number;
  custoFrota: number;
  perdaInadimplencia: number;
  margemBruta: number;
  despesasMarketing: number;
  despesasComerciais: number;
  despesasOperacionais: number;
  despesasAdministrativas: number;
  ebitda: number;
  depreciacao: number;
  resultadoFinanceiro: number;
  impostosSobreLucro: number;
  lucroLiquido: number;
  margemLiquidaPct: number; // lucro líquido / receita bruta (0..1)
}

/** Fluxo de caixa mensal (calculateCashFlow). */
export interface CashFlow {
  caixaInicial: number;
  entradas: number; // receita líquida (R$)
  saidas: number; // custos + despesas (R$)
  caixaMensal: number; // entradas - saidas (R$)
  caixaFinal: number; // caixaInicial + caixaMensal (R$)
}

/** Unit economics (calculateUnitEconomics). */
export interface UnitEconomics {
  margemMensalPorMotorista: number; // margem de contribuição mensal por motorista (R$)
  margemContribuicaoPorCarro: number; // margem de contribuição por carro/mês (R$)
  ltv: number; // valor do tempo de vida do cliente (R$)
  cacTotal: number; // custo de aquisição total (R$)
  ltvCac: number; // razão LTV / CAC
  paybackCacMeses: number; // meses para recuperar o CAC
  vidaMediaMeses: number; // 1 / churn
}

/** Ponto de equilíbrio (calculateBreakEven). */
export interface BreakEven {
  margemContribuicaoPorCarro: number;
  despesasFixasTotais: number;
  breakEvenCarros: number; // nº de carros para empatar
  carrosAtivos: number;
  folgaCarros: number; // carrosAtivos - breakEvenCarros
}

/** Resultado completo de um único cenário. */
export interface CalculationResult {
  fleet: FleetCosts;
  offer: OfferRevenue;
  funnel: MarketingFunnel;
  salesTeam: SalesTeam;
  supportTeam: SupportTeam;
  credit: CreditRevenue;
  dre: DRE;
  cashFlow: CashFlow;
  unitEconomics: UnitEconomics;
  breakEven: BreakEven;
}

/** Severidade de um alerta de validação. */
export type AlertSeverity = "aviso" | "perigo";

/** Alerta gerado por validateAssumptions. */
export interface ValidationAlert {
  campo: string;
  severidade: AlertSeverity;
  mensagem: string;
}

/** Identificador de cenário. */
export type ScenarioId = "conservador" | "base" | "agressivo" | "stress";

/** Definição de um cenário (nome + overrides sobre a base). */
export interface Scenario {
  id: ScenarioId;
  nome: string;
  descricao: string;
  overrides: Partial<import("./business").Assumptions>;
}

/** Resultado de um cenário já calculado (para comparação lado a lado). */
export interface ScenarioResult {
  id: ScenarioId;
  nome: string;
  result: CalculationResult;
  alerts: ValidationAlert[];
}
