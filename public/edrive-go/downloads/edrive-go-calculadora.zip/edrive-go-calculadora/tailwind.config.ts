import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "class",
  content: [
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        brand: {
          50: "#eefdf3",
          100: "#d6f9e2",
          200: "#aff0c8",
          300: "#78e2a7",
          400: "#3ecb80",
          500: "#17b165",
          600: "#0b8f51",
          700: "#0a7143",
          800: "#0c5937",
          900: "#0b492f",
        },
        surface: {
          DEFAULT: "#0f1115",
          card: "#171a21",
          soft: "#1f232d",
          border: "#2a2f3a",
        },
      },
      fontFamily: {
        sans: ["var(--font-sans)", "system-ui", "sans-serif"],
      },
    },
  },
  plugins: [],
};

export default config;
