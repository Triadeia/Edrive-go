import { defineConfig } from "vitest/config";
import { fileURLToPath } from "node:url";
import path from "node:path";

const dirname = path.dirname(fileURLToPath(import.meta.url));

/**
 * Configuração do Vitest.
 * Resolve o alias "@/" -> "src/" para que os testes importem a engine
 * exatamente como a aplicação Next.js faz.
 */
export default defineConfig({
  resolve: {
    alias: {
      "@": path.resolve(dirname, "src"),
    },
  },
  test: {
    environment: "node",
    include: ["src/tests/**/*.test.ts"],
    globals: true,
  },
});
