# Guia de deploy — Vercel

A forma mais simples de publicar a calculadora Intense Drive é pela **Vercel** (criadora do Next.js).

## Pré-requisitos

- Conta no [GitHub](https://github.com) (ou GitLab/Bitbucket).
- Conta na [Vercel](https://vercel.com) (o plano gratuito atende).
- Node.js 18+ instalado localmente (para testar antes).

## Passo 1 — Testar localmente

```bash
npm install
npm run test     # garante que a engine passa nos testes
npm run build    # garante que compila sem erros
npm run dev      # http://localhost:3000
```

## Passo 2 — Enviar o código para um repositório Git

```bash
git init
git add .
git commit -m "Intense Drive — calculadora financeira"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/intense-drive-calculadora.git
git push -u origin main
```

## Passo 3 — Importar na Vercel

1. Acesse [vercel.com/new](https://vercel.com/new).
2. Clique em **Import Git Repository** e selecione o repositório.
3. A Vercel detecta automaticamente o **Next.js**. Mantenha os padrões:
   - **Framework Preset**: Next.js
   - **Build Command**: `next build` (padrão)
   - **Output Directory**: `.next` (padrão)
   - **Install Command**: `npm install` (padrão)
4. Clique em **Deploy**.

Em ~1 minuto o app estará no ar em uma URL `https://SEU-PROJETO.vercel.app`.

> Não há variáveis de ambiente obrigatórias — a aplicação é 100% front-end
> (cálculo no cliente, sem banco de dados nem API externa).

## Passo 4 — Deploys automáticos

A cada `git push` na branch `main`, a Vercel refaz o build e publica automaticamente.
Pull requests ganham **preview deployments** com URL própria.

## Alternativa — Vercel CLI

```bash
npm i -g vercel
vercel          # primeiro deploy (preview)
vercel --prod   # promove para produção
```

## Alternativa — build estático / outros provedores

Como não há rotas de servidor, você também pode hospedar em qualquer provedor que rode Next.js
(Netlify, Render, Railway) ou servir o build gerado. Para a maioria dos casos, a Vercel é a rota
mais rápida e sem configuração.

## Solução de problemas

- **Erro de build por tipo**: rode `npm run build` localmente e corrija o que o TypeScript apontar.
- **Estilos não aplicam**: confirme que `tailwind.config.ts` inclui os caminhos de `src/app` e `src/components` em `content`.
- **Testes falhando no CI**: `npm test` usa Vitest com o alias `@/` configurado em `vitest.config.ts`.
