# Guia de uso — Calculadora Intense Drive

Este guia explica como operar a calculadora no dia a dia.

## 1. Escolha um cenário

No topo da tela há o seletor de **cenário**:

- **Conservador** — visão pessimista/prudente.
- **Base** — cenário central (premissas padrão).
- **Agressivo** — visão otimista.
- **Stress** — teste de resistência (choque adverso).

Ao clicar num cenário, todas as premissas são preenchidas com os valores daquele cenário.
A partir daí você pode **ajustar qualquer campo** livremente para simular variações.

## 2. Ajuste as premissas

Os inputs estão organizados em cards por bloco:

- **Frota** — custos por carro, ocupação, sinistros.
- **Oferta ao motorista** — mensalidade, ativação, churn, inadimplência.
- **Marketing** — investimento de mídia, CPL e taxas do funil.
- **Vendas** — produtividade e salários da equipe comercial.
- **Suporte / Operação** — atendimento e gestão de frota.
- **Crédito / Consórcio** — receita complementar.
- **Estrutura & Impostos** — despesas fixas, impostos e caixa.

Cada campo tem **slider** e **campo numérico** sincronizados: mexa em um e o outro acompanha.
Campos percentuais mostram `%` no número (ex.: 92%) mas guardam a fração internamente (0,92).

## 3. Leia os resultados

- **Dashboard** (topo): KPIs principais — Receita bruta/líquida, Custo frota, EBITDA,
  Lucro líquido, Margem líquida, CAC, LTV, LTV/CAC, Payback, Break-even de carros,
  Carros ativos e Caixa mensal.
- **DRE**: demonstração de resultado detalhada, da receita ao lucro líquido.
- **Funil de marketing**: de leads a contratos, com CAC.
- **Comparação de cenários**: os 4 cenários lado a lado.

## 4. Alertas

O banner de alertas aparece automaticamente quando alguma premissa sai da faixa saudável:

| Situação | Severidade |
|---|---|
| CPL acima de R$ 50 | aviso |
| Taxa de fechamento abaixo de 25% | aviso |
| **Margem de contribuição por carro negativa** | **perigo** |
| Ocupação abaixo de 80% | aviso |
| Inadimplência acima de 10% | perigo |
| LTV/CAC abaixo de 3x | aviso |
| Break-even de carros maior que a frota | perigo |

O alerta de **margem negativa** significa que o aluguel da locadora ficou maior que a receita
líquida por carro — a recomendação é renegociar o aluguel, aumentar o preço ao motorista ou
aumentar a ocupação.

## 5. Exportar e compartilhar

No topo à direita:

- **Exportar CSV** — baixa um `.csv` com todas as premissas e resultados do cenário atual
  (separador `;`, compatível com Excel em pt-BR).
- **Copiar link** — copia uma URL que reproduz exatamente o estado atual (premissas + cenário).
  Basta colar o link para outra pessoa abrir a mesma simulação.

## 6. Persistência

- Suas edições são salvas automaticamente no **localStorage** do navegador.
- Ao reabrir a página, o último estado é restaurado.
- Prioridade de carregamento: **URL** (link compartilhado) → **localStorage** → **padrão base**.
- Use **↺ Restaurar padrão** para voltar às premissas originais do cenário Base.

## Glossário rápido

- **CAC**: custo de aquisição de cliente.
- **LTV**: valor do tempo de vida do cliente (`margem mensal × 1/churn`).
- **LTV/CAC**: eficiência de aquisição (ideal ≥ 3x).
- **Payback CAC**: meses para recuperar o custo de aquisição.
- **Margem de contribuição por carro**: receita líquida por carro menos o custo da frota por carro.
- **Break-even de carros**: nº de carros necessários para cobrir as despesas fixas.
