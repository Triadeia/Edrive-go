# Intense Drive — Calculadora Financeira Dinâmica

Calculadora financeira interativa para a operação da **Intense Drive**: locação de **100 carros elétricos BYD Dolphin Mini** para motoristas de aplicativo.

Simule frota, oferta ao motorista, funil de marketing, dimensionamento de equipe, crédito/consórcio, DRE, unit economics e ponto de equilíbrio — com **4 cenários** (Conservador, Base, Agressivo, Stress), alertas automáticos, exportação CSV e links compartilháveis.

---

## Stack

- **Next.js 14** (App Router) + **React 18** + **TypeScript**
- **TailwindCSS** (tema dark)
- **Vitest** para testes da engine
- Sem dependências pagas
- Persistência via **localStorage**; parâmetros compartilhados via **querystring** na URL
- Exportação **CSV nativa** (sem bibliotecas)

---

## Como rodar

```bash
npm install
npm run dev      # http://localhost:3000
npm run build    # build de produção
npm start        # roda o build
npm test         # roda os testes (Vitest)
```

---

## Arquitetura

A **engine de cálculo é pura e separada da UI** — nenhuma função de cálculo acessa DOM, `localStorage` ou a URL. Isso torna todo o modelo testável isoladamente.

```
src/
├─ app/                     # App Router (layout, página, estilos globais)
│  ├─ layout.tsx
│  ├─ page.tsx              # monta Provider + Layout
│  └─ globals.css
├─ components/              # UI (React client components)
│  ├─ CalculatorContext.tsx # estado central (useReducer + Context) + sync URL/localStorage
│  ├─ CalculatorLayout.tsx  # organiza topo, dashboard, blocos e tabelas
│  ├─ Dashboard.tsx         # KPIs (ResultCards)
│  ├─ *Calculator.tsx       # blocos de input (Fleet, Offer, Marketing, Team, Support, Credit, Structure)
│  ├─ SliderInput.tsx       # slider + NumberInput sincronizados
│  ├─ DreTable.tsx / FunnelTable.tsx / ScenarioComparison.tsx
│  ├─ AlertBanner.tsx / ExportButtons.tsx / ScenarioSelector.tsx
│  └─ InputCard.tsx / ResultCard.tsx / NumberInput.tsx
├─ lib/
│  ├─ formulas.ts           # FÓRMULAS ATÔMICAS puras (uma por fórmula)
│  ├─ calculationEngine.ts  # engine: compõe as fórmulas em objetos tipados
│  ├─ scenarios.ts          # os 4 cenários (overrides)
│  ├─ validations.ts        # regras -> alertas
│  ├─ exportCsv.ts          # CSV nativo (pura) + download (efeito)
│  ├─ urlState.ts           # querystring + localStorage
│  └─ formatters.ts         # formatação pt-BR (BRL, %, etc.)
├─ data/
│  └─ defaultAssumptions.ts # premissas padrão (cenário base)
├─ types/
│  ├─ business.ts           # interface Assumptions
│  └─ calculator.ts         # tipos de resultado
└─ tests/
   ├─ formulas.test.ts
   └─ calculationEngine.test.ts
```

---

## Como as fórmulas mapeiam para as funções

Cada fórmula do modelo vive em `src/lib/formulas.ts` como função atômica pura; a engine
(`src/lib/calculationEngine.ts`) as compõe em objetos tipados.

| Bloco | Fórmula (resumo) | Função atômica (`formulas.ts`) | Função da engine (`calculationEngine.ts`) |
|---|---|---|---|
| Frota | `carros_ativos = totalCarros * taxaOcupacao * (1 - pctCarrosParados)` | `carrosAtivos()` | `calculateFleetCosts()` |
| Frota | `custo_frota = totalCarros * (custos por carro) + sinistro` | `custoFrota()` | `calculateFleetCosts()` |
| Receita | `receita_bruta = frota + ativação + complementar` | `receitaBruta()`, `receitaMensalFrota()`, `receitaAtivacao()` | `calculateOfferRevenue()` |
| Receita | `deducoes`, `receita_liquida` | `deducoes()`, `receitaLiquida()` | `calculateOfferRevenue()` |
| Risco | `perda_inadimplencia = receita_frota * inad * (1 - recup)` | `perdaInadimplencia()` | `calculateDRE()` |
| Funil | `leads → participantes → aplicações → aprovados → contratos` | `leadsGerados()`, `participantesWebinar()`, `aplicacoes()`, `aprovados()`, `contratos()` | `calculateMarketingFunnel()` |
| Funil | `CAC_marketing`, `CAC_total` | `cacMarketing()`, `cacTotal()` | `calculateMarketingFunnel()` |
| Equipe | `SDRs`, `closers`, `operadores`, `analistas` (ceil) | `numSDRs()`, `numClosers()`, `numOperadores()`, `numAnalistas()` | `calculateSalesTeam()` |
| Suporte | `atendentes`, `gestores_frota` (ceil) | `numAtendentes()`, `numGestoresFrota()` | `calculateSupportTeam()` |
| Consórcio | comissões líquidas de consórcio | — | `calculateCreditRevenue()` |
| DRE | `margem_bruta`, `EBITDA`, `lucro_liquido` | `margemBruta()`, `ebitda()`, `lucroLiquido()` | `calculateDRE()` |
| Caixa | entradas/saídas/caixa mensal | — | `calculateCashFlow()` |
| Unit econ. | `margem_contribuicao_por_carro`, `LTV`, `LTV/CAC`, `payback` | `margemContribuicaoPorCarro()`, `ltv()`, `ltvCac()`, `paybackCacMeses()` | `calculateUnitEconomics()` |
| Break-even | `break_even_carros = despesasFixas / margem_por_carro` | `breakEvenCarros()` | `calculateBreakEven()` |
| Cenários | aplica overrides e recalcula tudo | — | `calculateScenarios()` |
| Validação | gera alertas de negócio | — | `validateAssumptions()` |
| Export | serializa cenário em CSV | — | `exportScenarioToCSV()` |

> Onde o enunciado pede **teto**, usamos `Math.ceil` (ver `numSDRs`, `numClosers`, `numAtendentes`, `numGestoresFrota`, `numOperadores`, `numAnalistas`).

---

## Cenários

| Cenário | Ideia | Principais overrides |
|---|---|---|
| **Base** | operação central | premissas padrão |
| **Conservador** | aquisição cara, ocupação/fechamento menores | CPL 35, fechamento 30%, aluguel 3200, inadimplência 12%, ocupação 82%, churn 9%, mensalidade 3600 |
| **Agressivo** | aquisição barata, ocupação alta | CPL 12, fechamento 50%, aluguel 2500, inadimplência 4%, ocupação 95%, churn 4%, mensalidade 4100, consórcio 22% |
| **Stress** | choque adverso | CPL 60, fechamento 25%, aluguel 3400, inadimplência 18%, ocupação 70%, churn 12%, carros parados 15%, sinistro 4% |

---

## Testes

```bash
npm test
```

Cobrem: custos de frota, funil (leads→contratos), dimensionamento por `ceil`,
fechamento da DRE, unit economics (LTV, LTV/CAC, payback), break-even,
validações (margem negativa) e a comparação de cenários (Stress < Base < Agressivo em EBITDA).

---

## Observações

- Os valores são **mensais** e em **R$**.
- O modelo é uma ferramenta de simulação; ajuste as premissas à sua realidade.
- Ver `GUIA_DE_USO.md` e `GUIA_DE_DEPLOY.md`.
