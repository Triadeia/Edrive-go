import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Intense Drive — Calculadora Financeira",
  description:
    "Calculadora financeira dinâmica da Intense Drive: locação de 100 BYD Dolphin Mini para motoristas de app. Cenários, DRE, unit economics e break-even.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="pt-BR" className="dark">
      <body className="min-h-screen bg-surface text-slate-100 antialiased">
        {children}
      </body>
    </html>
  );
}
