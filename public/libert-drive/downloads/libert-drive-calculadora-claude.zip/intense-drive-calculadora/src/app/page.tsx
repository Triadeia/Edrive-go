"use client";

import { CalculatorProvider } from "@/components/CalculatorContext";
import CalculatorLayout from "@/components/CalculatorLayout";

/**
 * Página principal da calculadora Intense Drive.
 * O provider mantém o estado central (premissas + cenário) e sincroniza
 * com a URL e o localStorage; o layout monta toda a interface.
 */
export default function Page() {
  return (
    <main>
      <CalculatorProvider>
        <CalculatorLayout />
      </CalculatorProvider>
    </main>
  );
}
