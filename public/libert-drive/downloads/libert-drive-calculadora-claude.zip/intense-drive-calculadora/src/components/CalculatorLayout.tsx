"use client";

import ScenarioSelector from "./ScenarioSelector";
import ExportButtons from "./ExportButtons";
import AlertBanner from "./AlertBanner";
import Dashboard from "./Dashboard";
import FleetCalculator from "./FleetCalculator";
import OfferCalculator from "./OfferCalculator";
import MarketingCalculator from "./MarketingCalculator";
import TeamCalculator from "./TeamCalculator";
import SupportCalculator from "./SupportCalculator";
import CreditCalculator from "./CreditCalculator";
import StructureCalculator from "./StructureCalculator";
import DreTable from "./DreTable";
import FunnelTable from "./FunnelTable";
import ScenarioComparison from "./ScenarioComparison";
import { useCalculator } from "./CalculatorContext";

/**
 * CalculatorLayout — organiza o topo (cenário + export), o dashboard,
 * os blocos de inputs e as tabelas de saída (DRE, funil, comparação).
 */
export default function CalculatorLayout() {
  const { reset } = useCalculator();

  return (
    <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
      {/* Cabeçalho */}
      <header className="mb-6">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-2xl">⚡</span>
              <h1 className="text-2xl font-bold text-slate-100">Intense Drive</h1>
            </div>
            <p className="mt-1 text-sm text-slate-400">
              Calculadora financeira — locação de 100 BYD Dolphin Mini para motoristas de app.
            </p>
          </div>
          <ExportButtons />
        </div>

        <div className="mt-4 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-surface-border bg-surface-card p-3">
          <ScenarioSelector />
          <button
            type="button"
            onClick={reset}
            className="rounded-lg px-3 py-1.5 text-xs text-slate-400 hover:text-slate-200"
          >
            ↺ Restaurar padrão
          </button>
        </div>
      </header>

      {/* Alertas */}
      <div className="mb-6">
        <AlertBanner />
      </div>

      {/* Dashboard de KPIs */}
      <div className="mb-8">
        <Dashboard />
      </div>

      {/* Grade de inputs por bloco */}
      <div className="mb-8 grid grid-cols-1 gap-5 lg:grid-cols-2 xl:grid-cols-3">
        <FleetCalculator />
        <OfferCalculator />
        <MarketingCalculator />
        <TeamCalculator />
        <SupportCalculator />
        <CreditCalculator />
        <StructureCalculator />
      </div>

      {/* Saídas detalhadas */}
      <div className="mb-8 grid grid-cols-1 gap-5 lg:grid-cols-2">
        <DreTable />
        <FunnelTable />
      </div>

      {/* Comparação de cenários */}
      <div className="mb-10">
        <ScenarioComparison />
      </div>

      <footer className="pb-8 text-center text-xs text-slate-600">
        Intense Drive · Calculadora financeira dinâmica · Valores em R$ (mensais).
      </footer>
    </div>
  );
}
