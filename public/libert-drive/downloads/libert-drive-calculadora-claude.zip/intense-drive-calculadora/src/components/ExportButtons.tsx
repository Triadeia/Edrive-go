"use client";

import { useState } from "react";
import { useCalculator } from "./CalculatorContext";
import { exportScenarioToCSV, downloadCsv } from "@/lib/exportCsv";
import { buildShareUrl } from "@/lib/urlState";
import { scenarios } from "@/lib/scenarios";

/** Botões de exportação: CSV nativo e copiar link compartilhável. */
export default function ExportButtons() {
  const { assumptions, result, scenarioId } = useCalculator();
  const [copiado, setCopiado] = useState(false);

  const exportarCsv = () => {
    const nome = scenarios[scenarioId].nome;
    const conteudo = exportScenarioToCSV(nome, assumptions, result);
    downloadCsv(`intense-drive-${scenarioId}`, conteudo);
  };

  const copiarLink = async () => {
    const url = buildShareUrl({ assumptions, scenarioId });
    try {
      await navigator.clipboard.writeText(url);
      setCopiado(true);
      setTimeout(() => setCopiado(false), 2000);
    } catch {
      // Fallback: mostra a URL para cópia manual.
      window.prompt("Copie o link:", url);
    }
  };

  return (
    <div className="flex items-center gap-2">
      <button
        type="button"
        onClick={exportarCsv}
        className="rounded-lg border border-surface-border bg-surface-soft px-3 py-1.5 text-sm font-medium text-slate-200 hover:border-brand-600"
      >
        ⬇ Exportar CSV
      </button>
      <button
        type="button"
        onClick={copiarLink}
        className="rounded-lg border border-surface-border bg-surface-soft px-3 py-1.5 text-sm font-medium text-slate-200 hover:border-brand-600"
      >
        {copiado ? "✓ Link copiado" : "🔗 Copiar link"}
      </button>
    </div>
  );
}
