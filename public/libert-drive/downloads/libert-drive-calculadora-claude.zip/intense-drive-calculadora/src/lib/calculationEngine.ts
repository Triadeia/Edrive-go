/**
 * calculationEngine.ts — Engine PURA da Intense Drive.
 *
 * Todas as funções recebem o objeto de premissas (Assumptions) e retornam
 * objetos tipados. NÃO há acesso a DOM, localStorage, URL ou qualquer estado global.
 * Isso torna a engine 100% testável (ver src/tests).
 *
 * A engine compõe as fórmulas atômicas de formulas.ts.
 */

import type { Assumptions } from "@/types/business";
import type {
  BreakEven,
  CalculationResult,
  CashFlow,
  CreditRevenue,
  DRE,
  FleetCosts,
  MarketingFunnel,
  OfferRevenue,
  SalesTeam,
  ScenarioId,
  ScenarioResult,
  SupportTeam,
  UnitEconomics,
  ValidationAlert,
} from "@/types/calculator";
import * as F from "./formulas";
import { scenarios } from "./scenarios";
import { defaultAssumptions } from "@/data/defaultAssumptions";
import { validateAssumptions as validateAssumptionsImpl } from "./validations";

/** Mescla a base com os overrides de um cenário. */
export function buildAssumptions(
  base: Assumptions,
  overrides: Partial<Assumptions>
): Assumptions {
  return { ...base, ...overrides };
}

/**
 * calculateFleetCosts — custos e disponibilidade da frota.
 */
export function calculateFleetCosts(a: Assumptions): FleetCosts {
  const ativos = F.carrosAtivos(a.totalCarros, a.taxaOcupacao, a.pctCarrosParados);
  const parados = a.totalCarros - ativos;

  const custoFixoPorCarro =
    a.custoAluguelVeiculoMes +
    a.seguroMes +
    a.telemetriaMes +
    a.manutencaoMes +
    a.pneusMes +
    a.lavagemMes +
    a.patioAdminMes;

  const custoOperacionalTotal = a.totalCarros * custoFixoPorCarro;
  const custoSinistroTotal = a.pctSinistroMes * a.totalCarros * a.custoSinistroMedio;

  const custoFrotaTotal = F.custoFrota({
    totalCarros: a.totalCarros,
    custoAluguelVeiculoMes: a.custoAluguelVeiculoMes,
    seguroMes: a.seguroMes,
    telemetriaMes: a.telemetriaMes,
    manutencaoMes: a.manutencaoMes,
    pneusMes: a.pneusMes,
    lavagemMes: a.lavagemMes,
    patioAdminMes: a.patioAdminMes,
    pctSinistroMes: a.pctSinistroMes,
    custoSinistroMedio: a.custoSinistroMedio,
  });

  return {
    carrosAtivos: ativos,
    carrosParados: parados,
    custoOperacionalPorCarro: custoFixoPorCarro,
    custoOperacionalTotal,
    custoSinistroTotal,
    custoFrota: custoFrotaTotal,
    custoFrotaPorCarro: F.safeDiv(custoFrotaTotal, a.totalCarros),
  };
}

/**
 * calculateMarketingFunnel — do investimento de mídia até os contratos fechados.
 * Depende da folha comercial para o CAC total, então recebe salariosComerciais e comissoes.
 */
export function calculateMarketingFunnel(
  a: Assumptions,
  salariosComerciais = 0,
  comissoes = 0
): MarketingFunnel {
  const leads = F.leadsGerados(a.investimentoMarketingMes, a.cpl);
  const participantes = F.participantesWebinar({
    leadsGerados: leads,
    taxaLeadParaGrupo: a.taxaLeadParaGrupo,
    taxaGrupoParaWebinar: a.taxaGrupoParaWebinar,
    taxaComparecimento: a.taxaComparecimento,
  });
  const apps = F.aplicacoes(participantes, a.taxaAplicacao);
  const aprov = F.aprovados(apps, a.taxaAprovacao);
  const ctr = F.contratos(aprov, a.taxaFechamento);

  return {
    leadsGerados: leads,
    participantesWebinar: participantes,
    aplicacoes: apps,
    aprovados: aprov,
    contratos: ctr,
    cacMarketing: F.cacMarketing(a.investimentoMarketingMes, ctr),
    cacTotal: F.cacTotal({
      investimentoMarketingMes: a.investimentoMarketingMes,
      salariosComerciais,
      comissoes,
      contratos: ctr,
    }),
    investimentoMarketingMes: a.investimentoMarketingMes,
  };
}

/**
 * calculateSalesTeam — dimensiona SDRs, closers, operadores e analistas (teto).
 * Recebe o funil já calculado para reaproveitar leads/aplicacoes/contratos.
 */
export function calculateSalesTeam(
  a: Assumptions,
  funnel: MarketingFunnel
): SalesTeam {
  const sdrs = F.numSDRs(funnel.leadsGerados, a.leadsPorSDRMes);
  const closers = F.numClosers(funnel.aplicacoes, a.oportunidadesPorCloserMes);
  const operadores = F.numOperadores(funnel.contratos, a.entregasPorOperadorMes);
  const analistas = F.numAnalistas(funnel.aplicacoes, a.aplicacoesPorAnalistaMes);
  // Um gerente comercial para coordenar o time.
  const gerentes = 1;

  const salariosComerciais =
    sdrs * a.salarioSDR +
    closers * a.salarioCloser +
    operadores * a.salarioOperador +
    analistas * a.salarioAnalista +
    gerentes * a.salarioGerenteComercial;

  const comissoes = funnel.contratos * a.comissaoPorContrato;

  return {
    sdrs,
    closers,
    operadores,
    analistas,
    gerentes,
    salariosComerciais,
    comissoes,
    custoComercialTotal: salariosComerciais + comissoes,
  };
}

/**
 * calculateSupportTeam — dimensiona atendentes e gestores de frota (teto).
 */
export function calculateSupportTeam(
  a: Assumptions,
  fleet: FleetCosts
): SupportTeam {
  const atendentes = F.numAtendentes({
    carrosAtivos: fleet.carrosAtivos,
    ticketsPorMotoristaMes: a.ticketsPorMotoristaMes,
    capacidadeTicketsPorAtendente: a.capacidadeTicketsPorAtendente,
  });
  const gestoresFrota = F.numGestoresFrota(a.totalCarros, a.carrosPorGestorFrota);

  const custoSuporteTotal =
    atendentes * a.salarioAtendente + gestoresFrota * a.salarioGestorFrota;

  return { atendentes, gestoresFrota, custoSuporteTotal };
}

/**
 * calculateCreditRevenue — receita complementar de crédito/consórcio.
 */
export function calculateCreditRevenue(
  a: Assumptions,
  funnel: MarketingFunnel
): CreditRevenue {
  const interessados = funnel.leadsGerados * a.pctInteressadosConsorcio;
  const cartasBrutas = interessados * a.taxaConversaoConsorcio;
  // Desconta cancelamentos do consórcio.
  const cartasVendidas = cartasBrutas * (1 - a.pctCancelamentoConsorcio);

  const receitaConsorcio = cartasVendidas * a.comissaoMediaConsorcio;
  const custoCompliance = cartasVendidas * a.custoCompliancePorOp;

  return {
    interessados,
    cartasVendidas,
    receitaConsorcio,
    custoCompliance,
    receitaLiquidaConsorcio: receitaConsorcio - custoCompliance,
  };
}

/**
 * calculateOfferRevenue — receita da oferta ao motorista (frota + ativação + complementar).
 */
export function calculateOfferRevenue(
  a: Assumptions,
  fleet: FleetCosts,
  funnel: MarketingFunnel,
  credit: CreditRevenue
): OfferRevenue {
  const recMensalFrota = F.receitaMensalFrota(
    fleet.carrosAtivos,
    a.valorMensalMotorista
  );
  const recAtivacao = F.receitaAtivacao(funnel.contratos, a.taxaAtivacao);
  const recComplementar = credit.receitaLiquidaConsorcio;

  const recBruta = F.receitaBruta(recMensalFrota, recAtivacao, recComplementar);
  const ded = F.deducoes(recBruta, a.impostosSobreReceita);
  const recLiquida = F.receitaLiquida(recBruta, ded);

  return {
    carrosAtivos: fleet.carrosAtivos,
    novosContratos: funnel.contratos,
    receitaMensalFrota: recMensalFrota,
    receitaAtivacao: recAtivacao,
    receitaComplementar: recComplementar,
    receitaBruta: recBruta,
    deducoes: ded,
    receitaLiquida: recLiquida,
  };
}

/**
 * calculateDRE — Demonstração de Resultado do mês.
 */
export function calculateDRE(
  a: Assumptions,
  fleet: FleetCosts,
  offer: OfferRevenue,
  salesTeam: SalesTeam,
  supportTeam: SupportTeam
): DRE {
  const perdaInad = F.perdaInadimplencia(
    offer.receitaMensalFrota,
    a.inadimplenciaMensal,
    a.pctRecuperacaoInadimplencia
  );

  const margBruta = F.margemBruta(offer.receitaLiquida, fleet.custoFrota, perdaInad);

  // Buckets de despesa
  const despesasMarketing = a.investimentoMarketingMes;
  const despesasComerciais = salesTeam.custoComercialTotal;
  const despesasOperacionais = supportTeam.custoSuporteTotal;
  const despesasAdministrativas = a.despesasAdministrativasMes + a.ferramentasMes;

  const ebit = F.ebitda({
    margemBruta: margBruta,
    despesasMarketing,
    despesasComerciais,
    despesasOperacionais,
    despesasAdministrativas,
  });

  const impLucro = Math.max(0, ebit) * a.impostosSobreLucro;

  const lucro = F.lucroLiquido({
    ebitda: ebit,
    depreciacao: a.depreciacaoMes,
    resultadoFinanceiro: a.resultadoFinanceiroMes,
    impostosSobreLucro: impLucro,
  });

  return {
    receitaBruta: offer.receitaBruta,
    deducoes: offer.deducoes,
    receitaLiquida: offer.receitaLiquida,
    custoFrota: fleet.custoFrota,
    perdaInadimplencia: perdaInad,
    margemBruta: margBruta,
    despesasMarketing,
    despesasComerciais,
    despesasOperacionais,
    despesasAdministrativas,
    ebitda: ebit,
    depreciacao: a.depreciacaoMes,
    resultadoFinanceiro: a.resultadoFinanceiroMes,
    impostosSobreLucro: impLucro,
    lucroLiquido: lucro,
    margemLiquidaPct: F.safeDiv(lucro, offer.receitaBruta),
  };
}

/**
 * calculateCashFlow — fluxo de caixa mensal simplificado.
 */
export function calculateCashFlow(a: Assumptions, dre: DRE): CashFlow {
  const entradas = dre.receitaLiquida;
  const saidas =
    dre.custoFrota +
    dre.perdaInadimplencia +
    dre.despesasMarketing +
    dre.despesasComerciais +
    dre.despesasOperacionais +
    dre.despesasAdministrativas +
    dre.resultadoFinanceiro +
    dre.impostosSobreLucro;

  const caixaMensal = entradas - saidas;

  return {
    caixaInicial: a.caixaInicial,
    entradas,
    saidas,
    caixaMensal,
    caixaFinal: a.caixaInicial + caixaMensal,
  };
}

/**
 * calculateUnitEconomics — LTV, CAC, LTV/CAC e payback por motorista/carro.
 */
export function calculateUnitEconomics(
  a: Assumptions,
  fleet: FleetCosts,
  funnel: MarketingFunnel
): UnitEconomics {
  // Margem de contribuição por carro (receita líquida por carro menos custo da frota por carro).
  const margCarro = F.margemContribuicaoPorCarro({
    valorMensalMotorista: a.valorMensalMotorista,
    impostosSobreReceita: a.impostosSobreReceita,
    inadimplenciaMensal: a.inadimplenciaMensal,
    pctRecuperacaoInadimplencia: a.pctRecuperacaoInadimplencia,
    custoFrotaPorCarro: fleet.custoFrotaPorCarro,
  });

  // A margem mensal por motorista é a mesma margem de contribuição por carro ativo.
  const margemMensalPorMotorista = margCarro;

  const vidaMediaMeses = F.safeDiv(1, a.churnMensal);
  const ltvValor = F.ltv(margemMensalPorMotorista, a.churnMensal);
  const cac = funnel.cacTotal;

  return {
    margemMensalPorMotorista,
    margemContribuicaoPorCarro: margCarro,
    ltv: ltvValor,
    cacTotal: cac,
    ltvCac: F.ltvCac(ltvValor, cac),
    paybackCacMeses: F.paybackCacMeses(cac, margemMensalPorMotorista),
    vidaMediaMeses,
  };
}

/**
 * calculateBreakEven — número de carros para cobrir despesas fixas.
 */
export function calculateBreakEven(
  a: Assumptions,
  fleet: FleetCosts,
  dre: DRE,
  unit: UnitEconomics
): BreakEven {
  // Despesas fixas totais = despesas que não escalam diretamente com o carro individual.
  const despesasFixasTotais =
    dre.despesasMarketing +
    dre.despesasComerciais +
    dre.despesasOperacionais +
    dre.despesasAdministrativas +
    dre.depreciacao +
    dre.resultadoFinanceiro;

  const bec = F.breakEvenCarros(
    despesasFixasTotais,
    unit.margemContribuicaoPorCarro
  );

  return {
    margemContribuicaoPorCarro: unit.margemContribuicaoPorCarro,
    despesasFixasTotais,
    breakEvenCarros: bec,
    carrosAtivos: fleet.carrosAtivos,
    folgaCarros: fleet.carrosAtivos - bec,
  };
}

/**
 * calculate — ORQUESTRADOR: calcula o resultado completo para um conjunto de premissas.
 * Encadeia todas as funções na ordem de dependência.
 */
export function calculate(a: Assumptions): CalculationResult {
  const fleet = calculateFleetCosts(a);

  // Passo 1: funil preliminar (sem folha comercial) para dimensionar equipe.
  const funnelPre = calculateMarketingFunnel(a);
  const salesTeam = calculateSalesTeam(a, funnelPre);
  const supportTeam = calculateSupportTeam(a, fleet);

  // Passo 2: recalcula o funil com a folha comercial para obter o CAC total correto.
  const funnel = calculateMarketingFunnel(
    a,
    salesTeam.salariosComerciais,
    salesTeam.comissoes
  );

  const credit = calculateCreditRevenue(a, funnel);
  const offer = calculateOfferRevenue(a, fleet, funnel, credit);
  const dre = calculateDRE(a, fleet, offer, salesTeam, supportTeam);
  const cashFlow = calculateCashFlow(a, dre);
  const unitEconomics = calculateUnitEconomics(a, fleet, funnel);
  const breakEven = calculateBreakEven(a, fleet, dre, unitEconomics);

  return {
    fleet,
    offer,
    funnel,
    salesTeam,
    supportTeam,
    credit,
    dre,
    cashFlow,
    unitEconomics,
    breakEven,
  };
}

/**
 * validateAssumptions — regras de negócio que geram alertas.
 * Reexportado a partir de validations.ts para manter a assinatura pedida no enunciado.
 */
export const validateAssumptions = validateAssumptionsImpl;

/**
 * calculateScenarios — calcula os 4 cenários (aplicando overrides sobre a base fornecida).
 * A "base" recebida representa as premissas atuais editadas pelo usuário; cada cenário
 * aplica seus overrides sobre ela.
 */
export function calculateScenarios(
  base: Assumptions = defaultAssumptions
): ScenarioResult[] {
  const ids: ScenarioId[] = ["conservador", "base", "agressivo", "stress"];

  return ids.map((id) => {
    const scn = scenarios[id];
    const merged = buildAssumptions(base, scn.overrides);
    const result = calculate(merged);
    return {
      id,
      nome: scn.nome,
      result,
      alerts: validateAssumptionsImpl(merged, result) as ValidationAlert[],
    };
  });
}

/**
 * exportScenarioToCSV — serializa um resultado (e suas premissas) para CSV.
 * Reexporta a implementação de exportCsv.ts.
 */
export { exportScenarioToCSV } from "./exportCsv";
