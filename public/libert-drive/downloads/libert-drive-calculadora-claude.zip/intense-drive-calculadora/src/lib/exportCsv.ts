/**
 * exportCsv.ts — exportação CSV nativa (sem dependências).
 */

import type { Assumptions } from "@/types/business";
import type { CalculationResult } from "@/types/calculator";

/** Escapa um valor para CSV (aspas + separador). */
function escapeCsv(valor: string | number): string {
  const s = String(valor);
  if (s.includes(";") || s.includes('"') || s.includes("\n")) {
    return `"${s.replace(/"/g, '""')}"`;
  }
  return s;
}

/** Monta uma linha CSV a partir de células. */
function row(...celulas: (string | number)[]): string {
  return celulas.map(escapeCsv).join(";");
}

/**
 * exportScenarioToCSV — gera o conteúdo CSV (string) de um cenário:
 * premissas + principais resultados. Usa ';' como separador (padrão pt-BR/Excel).
 */
export function exportScenarioToCSV(
  nomeCenario: string,
  a: Assumptions,
  r: CalculationResult
): string {
  const linhas: string[] = [];

  linhas.push(row("Intense Drive — Calculadora Financeira"));
  linhas.push(row("Cenário", nomeCenario));
  linhas.push("");

  // ----- Premissas -----
  linhas.push(row("PREMISSAS", "Valor"));
  (Object.keys(a) as (keyof Assumptions)[]).forEach((k) => {
    linhas.push(row(k, a[k]));
  });
  linhas.push("");

  // ----- Resultados-chave -----
  linhas.push(row("RESULTADOS", "Valor"));
  const kv: [string, number][] = [
    ["Carros ativos", r.fleet.carrosAtivos],
    ["Custo frota", r.fleet.custoFrota],
    ["Custo frota por carro", r.fleet.custoFrotaPorCarro],
    ["Leads gerados", r.funnel.leadsGerados],
    ["Contratos", r.funnel.contratos],
    ["CAC marketing", r.funnel.cacMarketing],
    ["CAC total", r.funnel.cacTotal],
    ["SDRs", r.salesTeam.sdrs],
    ["Closers", r.salesTeam.closers],
    ["Operadores", r.salesTeam.operadores],
    ["Analistas", r.salesTeam.analistas],
    ["Atendentes", r.supportTeam.atendentes],
    ["Gestores de frota", r.supportTeam.gestoresFrota],
    ["Receita bruta", r.offer.receitaBruta],
    ["Deduções", r.offer.deducoes],
    ["Receita líquida", r.offer.receitaLiquida],
    ["Perda inadimplência", r.dre.perdaInadimplencia],
    ["Margem bruta", r.dre.margemBruta],
    ["EBITDA", r.dre.ebitda],
    ["Lucro líquido", r.dre.lucroLiquido],
    ["Margem líquida (%)", r.dre.margemLiquidaPct * 100],
    ["Caixa mensal", r.cashFlow.caixaMensal],
    ["Caixa final", r.cashFlow.caixaFinal],
    ["Margem contribuição por carro", r.unitEconomics.margemContribuicaoPorCarro],
    ["LTV", r.unitEconomics.ltv],
    ["LTV/CAC", r.unitEconomics.ltvCac],
    ["Payback CAC (meses)", r.unitEconomics.paybackCacMeses],
    ["Break-even carros", r.breakEven.breakEvenCarros],
  ];
  kv.forEach(([nome, valor]) => {
    const num = isFinite(valor) ? Number(valor.toFixed(2)) : valor;
    linhas.push(row(nome, num));
  });

  return linhas.join("\n");
}

/**
 * downloadCsv — dispara o download de um CSV no navegador (efeito colateral,
 * usado só pela UI). Mantido aqui por conveniência, mas separado da função pura acima.
 */
export function downloadCsv(nomeArquivo: string, conteudo: string): void {
  if (typeof window === "undefined") return;
  // BOM para o Excel reconhecer UTF-8.
  const blob = new Blob(["﻿" + conteudo], {
    type: "text/csv;charset=utf-8;",
  });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = nomeArquivo.endsWith(".csv") ? nomeArquivo : `${nomeArquivo}.csv`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
