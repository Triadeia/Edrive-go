/**
 * urlState.ts — serialização das premissas (e cenário ativo) para a querystring
 * e persistência em localStorage. Permite compartilhar links reproduzíveis.
 */

import type { Assumptions } from "@/types/business";
import type { ScenarioId } from "@/types/calculator";
import { defaultAssumptions } from "@/data/defaultAssumptions";

const STORAGE_KEY = "intense-drive:estado";
const PARAM_PREFIX = "p_"; // prefixo de cada premissa na URL
const SCENARIO_PARAM = "cenario";

/** Estado persistível: premissas + cenário selecionado. */
export interface PersistedState {
  assumptions: Assumptions;
  scenarioId: ScenarioId;
}

/** Aplica apenas as chaves numéricas conhecidas, ignorando lixo. */
function sanitize(parcial: Partial<Record<keyof Assumptions, number>>): Assumptions {
  const base: Assumptions = { ...defaultAssumptions };
  (Object.keys(defaultAssumptions) as (keyof Assumptions)[]).forEach((k) => {
    const v = parcial[k];
    if (typeof v === "number" && isFinite(v)) {
      base[k] = v;
    }
  });
  return base;
}

/** Serializa premissas + cenário em uma querystring (sem o '?'). */
export function encodeStateToQuery(state: PersistedState): string {
  const params = new URLSearchParams();
  params.set(SCENARIO_PARAM, state.scenarioId);
  (Object.keys(state.assumptions) as (keyof Assumptions)[]).forEach((k) => {
    params.set(PARAM_PREFIX + k, String(state.assumptions[k]));
  });
  return params.toString();
}

/** Lê a querystring atual e reconstrói o estado (ou null se vazia). */
export function decodeStateFromQuery(search: string): PersistedState | null {
  const params = new URLSearchParams(search);
  if ([...params.keys()].length === 0) return null;

  const parcial: Partial<Record<keyof Assumptions, number>> = {};
  (Object.keys(defaultAssumptions) as (keyof Assumptions)[]).forEach((k) => {
    const raw = params.get(PARAM_PREFIX + k);
    if (raw !== null) {
      const n = Number(raw);
      if (isFinite(n)) parcial[k] = n;
    }
  });

  const scenarioRaw = params.get(SCENARIO_PARAM) as ScenarioId | null;
  const scenarioId: ScenarioId =
    scenarioRaw === "conservador" ||
    scenarioRaw === "base" ||
    scenarioRaw === "agressivo" ||
    scenarioRaw === "stress"
      ? scenarioRaw
      : "base";

  return { assumptions: sanitize(parcial), scenarioId };
}

/** Monta o link completo compartilhável a partir do estado atual. */
export function buildShareUrl(state: PersistedState): string {
  if (typeof window === "undefined") return "";
  const { origin, pathname } = window.location;
  return `${origin}${pathname}?${encodeStateToQuery(state)}`;
}

/** Atualiza a URL do navegador sem recarregar a página. */
export function pushStateToUrl(state: PersistedState): void {
  if (typeof window === "undefined") return;
  const query = encodeStateToQuery(state);
  const newUrl = `${window.location.pathname}?${query}`;
  window.history.replaceState(null, "", newUrl);
}

/** Persiste o estado no localStorage. */
export function saveToLocalStorage(state: PersistedState): void {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch {
    /* storage indisponível — ignora silenciosamente */
  }
}

/** Recupera o estado do localStorage (ou null). */
export function loadFromLocalStorage(): PersistedState | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as PersistedState;
    return {
      assumptions: sanitize(parsed.assumptions as unknown as Partial<Record<keyof Assumptions, number>>),
      scenarioId: parsed.scenarioId ?? "base",
    };
  } catch {
    return null;
  }
}

/**
 * loadInitialState — prioridade: URL > localStorage > padrão base.
 */
export function loadInitialState(): PersistedState {
  if (typeof window !== "undefined") {
    const fromUrl = decodeStateFromQuery(window.location.search);
    if (fromUrl) return fromUrl;
    const fromStorage = loadFromLocalStorage();
    if (fromStorage) return fromStorage;
  }
  return { assumptions: { ...defaultAssumptions }, scenarioId: "base" };
}
