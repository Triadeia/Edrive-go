/**
 * Tipos de negócio da Intense Drive.
 * Este arquivo concentra a interface de PREMISSAS (assumptions) usada por toda a engine.
 * Todos os valores são editáveis pela UI; os padrões vivem em src/data/defaultAssumptions.ts.
 */

/**
 * Conjunto completo de premissas do modelo financeiro.
 * Cada campo tem comentário em pt-BR explicando a unidade.
 */
export interface Assumptions {
  // ---------- FROTA ----------
  totalCarros: number; // quantidade total de carros na operação
  custoAluguelVeiculoMes: number; // quanto a Intense Drive paga à locadora por carro/mês (R$)
  seguroMes: number; // seguro por carro/mês (R$)
  telemetriaMes: number; // rastreamento/telemetria por carro/mês (R$)
  manutencaoMes: number; // manutenção provisionada por carro/mês (R$)
  pneusMes: number; // provisão de pneus por carro/mês (R$)
  lavagemMes: number; // lavagem por carro/mês (R$)
  patioAdminMes: number; // pátio + custos administrativos por carro/mês (R$)
  pctCarrosParados: number; // fração de carros parados (0..1), ex.: manutenção/pátio
  pctSinistroMes: number; // fração de carros que sofrem sinistro por mês (0..1)
  custoSinistroMedio: number; // custo médio por sinistro (R$)
  taxaOcupacao: number; // fração da frota efetivamente alugada (0..1)

  // ---------- OFERTA AO MOTORISTA ----------
  valorMensalMotorista: number; // quanto o motorista paga por mês (R$)
  valorSemanalMotorista: number; // quanto o motorista paga por semana (R$) — referência comercial
  valorDiaMotorista: number; // quanto o motorista paga por dia (R$) — referência comercial
  taxaAtivacao: number; // taxa cobrada na ativação de cada novo contrato (R$)
  entradaSinalCaucao: number; // sinal/caução na entrada (R$) — referência comercial
  churnMensal: number; // fração de motoristas que saem por mês (0..1)
  inadimplenciaMensal: number; // fração da receita mensal inadimplente (0..1)
  pctRecuperacaoInadimplencia: number; // fração da inadimplência recuperada (0..1)
  prazoMedioContratoMeses: number; // prazo médio do contrato (meses) — referência

  // ---------- MARKETING / FUNIL ----------
  cpl: number; // custo por lead (R$)
  investimentoMarketingMes: number; // verba de mídia por mês (R$)
  taxaLeadParaGrupo: number; // fração de leads que entram no grupo (0..1)
  taxaGrupoParaWebinar: number; // fração do grupo que vai ao webinar (0..1)
  taxaComparecimento: number; // fração que efetivamente comparece (0..1)
  taxaAplicacao: number; // fração dos participantes que aplicam (0..1)
  taxaAprovacao: number; // fração das aplicações aprovadas em crédito (0..1)
  taxaFechamento: number; // fração dos aprovados que fecham contrato (0..1)

  // ---------- VENDAS / EQUIPE ----------
  leadsPorSDRMes: number; // leads que um SDR processa por mês
  oportunidadesPorCloserMes: number; // oportunidades que um closer atende por mês
  entregasPorOperadorMes: number; // entregas de veículo por operador/mês
  aplicacoesPorAnalistaMes: number; // aplicações analisadas por analista de crédito/mês
  salarioSDR: number; // salário mensal do SDR (R$)
  salarioCloser: number; // salário mensal do closer (R$)
  comissaoPorContrato: number; // comissão por contrato fechado (R$)
  salarioGerenteComercial: number; // salário do gerente comercial (R$)

  // ---------- SUPORTE / OPERAÇÃO ----------
  salarioAtendente: number; // salário do atendente de suporte (R$)
  carrosPorGestorFrota: number; // carros que um gestor de frota gerencia
  salarioGestorFrota: number; // salário do gestor de frota (R$)
  salarioOperador: number; // salário do operador de entregas (R$)
  salarioAnalista: number; // salário do analista de crédito (R$)
  ticketsPorMotoristaMes: number; // tickets de suporte por motorista/mês
  capacidadeTicketsPorAtendente: number; // tickets que um atendente resolve por mês
  custoRecuperacaoVeiculo: number; // custo de recuperar veículo em caso de inadimplência (R$)

  // ---------- CRÉDITO / CONSÓRCIO ----------
  pctInteressadosConsorcio: number; // fração de leads interessados em consórcio (0..1)
  taxaConversaoConsorcio: number; // fração dos interessados que convertem (0..1)
  comissaoMediaConsorcio: number; // comissão média por carta vendida (R$)
  ticketMedioCarta: number; // ticket médio da carta de consórcio (R$)
  pctCancelamentoConsorcio: number; // fração de cancelamento de consórcio (0..1)
  custoCompliancePorOp: number; // custo de compliance por operação de crédito (R$)

  // ---------- IMPOSTOS / ESTRUTURA / FINANCEIRO ----------
  impostosSobreReceita: number; // alíquota sobre receita bruta (0..1)
  impostosSobreLucro: number; // alíquota sobre lucro (0..1)
  despesasAdministrativasMes: number; // despesas administrativas fixas (R$)
  ferramentasMes: number; // ferramentas/software por mês (R$)
  depreciacaoMes: number; // depreciação mensal (R$)
  resultadoFinanceiroMes: number; // resultado financeiro mensal (R$; positivo = despesa)
  caixaInicial: number; // caixa inicial da operação (R$)
}

/** Nome de campo de premissa (chave de Assumptions). */
export type AssumptionKey = keyof Assumptions;
